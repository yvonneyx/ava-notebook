import { LifecycleEventType, AnalysisEventType } from './constant';
import type { AnalysisEventContext } from './types';
export declare class BaseEvent {
    type: string;
    constructor(type: string);
}
export declare class LifecycleEvent extends BaseEvent {
    data: object | null;
    constructor(type: LifecycleEventType, data?: object | null);
}
export declare class AnalysisEvent extends BaseEvent {
    data: object | null;
    context?: AnalysisEventContext;
    constructor(type: AnalysisEventType, data?: object | null, context?: AnalysisEventContext);
}
