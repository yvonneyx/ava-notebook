import type EventEmitter from '@antv/event-emitter';
import type { BaseEvent } from './events';
export * from './constant';
export * from './events';
export * from './types';
export declare function startOf(pairId: string): string;
export declare function endOf(pairId: string): string;
/**
 * Trigger event based on Event object
 */
export declare function emit(emitter: EventEmitter, event: BaseEvent): void;
