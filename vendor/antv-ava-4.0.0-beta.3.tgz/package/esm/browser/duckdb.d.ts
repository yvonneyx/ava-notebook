import type { DuckDBBundles } from '@duckdb/duckdb-wasm';
import type { AnalysisEngine, DataModel, DataSourceConfig, ExecutionOptions, ExecutionResult, LLMConfig, ProfileOptions, Schema } from '../types';
export interface DuckDBWasmEngineOptions {
    /** Self-hosted bundles are recommended; defaults to the package's versioned CDN bundles. */
    bundles?: DuckDBBundles;
    queryTimeoutMs?: number;
    /** Bound network download and worker startup. Default 60 seconds. */
    loadTimeoutMs?: number;
    memoryLimit?: string;
}
/** Browser SQL engine. All input and query execution stay inside a dedicated Wasm worker. */
export declare class DuckDBWasmEngine implements AnalysisEngine {
    private readonly llmConfig;
    private readonly options;
    readonly language: {
        name: string;
        fence: string;
    };
    private database;
    private connection;
    private worker;
    private ready;
    constructor(llmConfig: LLMConfig, options?: DuckDBWasmEngineOptions);
    private rows;
    private preparedRows;
    private adapter;
    private bounded;
    load(config: DataSourceConfig): Promise<void>;
    schema(): Promise<Schema>;
    profile(schema: Schema, options?: ProfileOptions): Promise<import("../types").Profile>;
    getDSL(query: string, dataModel: DataModel): Promise<string>;
    execute<T = Record<string, unknown>>(sql: string, options?: ExecutionOptions): Promise<ExecutionResult<T>>;
    dispose(): Promise<void>;
}
