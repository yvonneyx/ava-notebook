import type { Schema } from '../../types';
export declare function getClickHouseSchema(runQuery: (sql: string) => Promise<Record<string, unknown>[]>, database: string): Promise<Schema>;
