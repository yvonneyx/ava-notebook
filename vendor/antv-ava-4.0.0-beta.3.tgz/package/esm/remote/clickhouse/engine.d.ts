import type { AnalysisEngine, DataModel, DataSourceConfig, ExecutionOptions, ExecutionResult, LLMConfig, Profile, ProfileOptions, Schema } from '../../types';
export declare class ClickHouseEngine implements AnalysisEngine {
    readonly language: {
        name: string;
        fence: string;
    };
    private client;
    private database;
    private readonly queryDialect;
    constructor(llmConfig: LLMConfig);
    load(config: DataSourceConfig): Promise<void>;
    schema(): Promise<Schema>;
    profile(schema: Schema, options?: ProfileOptions): Promise<Profile>;
    getDSL(query: string, dataModel: DataModel): Promise<string>;
    execute<T = Record<string, unknown>>(dsl: string, options?: ExecutionOptions): Promise<ExecutionResult<T>>;
    dispose(): Promise<void>;
    private runQuery;
}
