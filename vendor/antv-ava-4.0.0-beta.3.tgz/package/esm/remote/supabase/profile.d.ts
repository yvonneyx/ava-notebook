import type { MetricField } from '../../util/profile';
import type { LogicalType, Metric, ParsedProfileOptions, Profile, Schema } from '../../types';
interface Context {
    table: string;
    column?: string;
    field?: MetricField;
    metric: ParsedProfileOptions['metrics'][number];
}
type PostgreSQLMetric = Metric<(context: Context) => string>;
export declare function logicalType(type: string): LogicalType;
export declare const BUILTIN_METRICS: PostgreSQLMetric[];
export declare function profileTables(runQuery: (sql: string) => Promise<Record<string, unknown>[]>, schema: Schema, options: ParsedProfileOptions): Promise<Profile>;
export {};
