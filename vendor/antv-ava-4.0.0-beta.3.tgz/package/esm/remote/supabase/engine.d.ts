/**
 * Supabase engine: LLM generates SQL, executed remotely through the Supabase
 * Management API (POST https://api.supabase.com/v1/projects/:ref/database/query).
 * Unlike DuckDBEngine, no data is materialized locally — the query endpoint
 * applies the read-only `supabase_read_only_user` role (read_only: true), so
 * LLM-generated SQL can never write to the project. The OAuth handshake
 * (authorize/token exchange/refresh) is out of scope: the consuming app
 * obtains the access token and passes it in the data source config.
 */
import type { Profile, ProfileOptions, AnalysisEngine, DataModel, DataSourceConfig, LLMConfig, Schema, ExecutionOptions, ExecutionResult } from '../../types';
export declare class SupabaseApiError extends Error {
    constructor(status: number, detail: string);
    readonly status: number;
    readonly detail: string;
}
export declare class SupabaseEngine implements AnalysisEngine {
    readonly language: {
        name: string;
        fence: string;
    };
    private connection;
    private readonly queryDialect;
    constructor(llmConfig: LLMConfig);
    load(config: DataSourceConfig): Promise<void>;
    schema(): Promise<Schema>;
    profile(schema: Schema, options?: ProfileOptions): Promise<Profile>;
    getDSL(query: string, dataModel: DataModel): Promise<string>;
    execute<T = Record<string, unknown>>(sql: string, options?: ExecutionOptions): Promise<ExecutionResult<T>>;
    dispose(): Promise<void>;
    /**
     * Execute a read-only SQL query through the Management API and return the
     * result rows.
     */
    private runQuery;
}
