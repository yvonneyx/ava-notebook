import type { Schema } from '../../types';
/** Only the public schema is read — Supabase user tables live there by default. */
export declare const SUPABASE_SCHEMA = "public";
/** One read-only catalog query for fields, indexes and foreign keys. */
export declare function getSupabaseSchema(runQuery: (sql: string) => Promise<Record<string, unknown>[]>): Promise<Schema>;
