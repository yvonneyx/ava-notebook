import type { ExecutionResult } from '../../../types';
/** Local subprocess execution, not a security sandbox. Requires python3 and pandas. */
export declare const createPythonExecutor: (timeoutMs: number) => (code: string, maxBuffer: number) => Promise<ExecutionResult>;
