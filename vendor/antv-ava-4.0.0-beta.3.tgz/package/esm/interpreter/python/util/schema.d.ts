import { z } from 'zod';
/** Validate the JSON output of the generated Python script. */
export declare const resultSchema: z.ZodEffects<z.ZodObject<{
    data: z.ZodArray<z.ZodRecord<z.ZodString, z.ZodType<import("../../..").JsonValue, z.ZodTypeDef, import("../../..").JsonValue>>, "many">;
    schema: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        type: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        name?: string;
        type?: string;
    }, {
        name?: string;
        type?: string;
    }>, "many">;
    truncated: z.ZodOptional<z.ZodLiteral<true>>;
    truncatedBy: z.ZodOptional<z.ZodEnum<["maxRows", "maxResultBytes"]>>;
    rowCount: z.ZodOptional<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    schema?: {
        name?: string;
        type?: string;
    }[];
    data?: Record<string, import("../../..").JsonValue>[];
    truncatedBy?: "maxRows" | "maxResultBytes";
    truncated?: true;
    rowCount?: number;
}, {
    schema?: {
        name?: string;
        type?: string;
    }[];
    data?: Record<string, import("../../..").JsonValue>[];
    truncatedBy?: "maxRows" | "maxResultBytes";
    truncated?: true;
    rowCount?: number;
}>, {
    schema?: {
        name?: string;
        type?: string;
    }[];
    data?: Record<string, import("../../..").JsonValue>[];
    truncatedBy?: "maxRows" | "maxResultBytes";
    truncated?: true;
    rowCount?: number;
}, {
    schema?: {
        name?: string;
        type?: string;
    }[];
    data?: Record<string, import("../../..").JsonValue>[];
    truncatedBy?: "maxRows" | "maxResultBytes";
    truncated?: true;
    rowCount?: number;
}>;
/** Validate and snapshot configuration; data loading runs in the generated script. */
export declare const sourceSchema: z.ZodEffects<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
    type: z.ZodLiteral<"csv">;
    options: z.ZodObject<{
        csv: z.ZodString;
        options: z.ZodOptional<z.ZodObject<{
            header: z.ZodOptional<z.ZodBoolean>;
            names: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
            delim: z.ZodOptional<z.ZodString>;
            quote: z.ZodOptional<z.ZodString>;
            escape: z.ZodOptional<z.ZodString>;
            comment: z.ZodOptional<z.ZodString>;
            skip: z.ZodOptional<z.ZodNumber>;
            nullstr: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>>;
            all_varchar: z.ZodOptional<z.ZodBoolean>;
            decimal_separator: z.ZodOptional<z.ZodString>;
            thousands: z.ZodOptional<z.ZodString>;
            encoding: z.ZodOptional<z.ZodString>;
            compression: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            header?: boolean;
            names?: string[];
            all_varchar?: boolean;
            delim?: string;
            quote?: string;
            escape?: string;
            comment?: string;
            decimal_separator?: string;
            thousands?: string;
            nullstr?: string | string[];
            skip?: number;
            encoding?: string;
            compression?: string;
        }, {
            header?: boolean;
            names?: string[];
            all_varchar?: boolean;
            delim?: string;
            quote?: string;
            escape?: string;
            comment?: string;
            decimal_separator?: string;
            thousands?: string;
            nullstr?: string | string[];
            skip?: number;
            encoding?: string;
            compression?: string;
        }>>;
    }, "strict", z.ZodTypeAny, {
        csv?: string;
        options?: {
            header?: boolean;
            names?: string[];
            all_varchar?: boolean;
            delim?: string;
            quote?: string;
            escape?: string;
            comment?: string;
            decimal_separator?: string;
            thousands?: string;
            nullstr?: string | string[];
            skip?: number;
            encoding?: string;
            compression?: string;
        };
    }, {
        csv?: string;
        options?: {
            header?: boolean;
            names?: string[];
            all_varchar?: boolean;
            delim?: string;
            quote?: string;
            escape?: string;
            comment?: string;
            decimal_separator?: string;
            thousands?: string;
            nullstr?: string | string[];
            skip?: number;
            encoding?: string;
            compression?: string;
        };
    }>;
}, "strip", z.ZodTypeAny, {
    options?: {
        csv?: string;
        options?: {
            header?: boolean;
            names?: string[];
            all_varchar?: boolean;
            delim?: string;
            quote?: string;
            escape?: string;
            comment?: string;
            decimal_separator?: string;
            thousands?: string;
            nullstr?: string | string[];
            skip?: number;
            encoding?: string;
            compression?: string;
        };
    };
    type?: "csv";
}, {
    options?: {
        csv?: string;
        options?: {
            header?: boolean;
            names?: string[];
            all_varchar?: boolean;
            delim?: string;
            quote?: string;
            escape?: string;
            comment?: string;
            decimal_separator?: string;
            thousands?: string;
            nullstr?: string | string[];
            skip?: number;
            encoding?: string;
            compression?: string;
        };
    };
    type?: "csv";
}>, z.ZodObject<{
    type: z.ZodLiteral<"json">;
    options: z.ZodObject<{
        data: z.ZodArray<z.ZodRecord<z.ZodString, z.ZodType<import("../../..").JsonValue, z.ZodTypeDef, import("../../..").JsonValue>>, "many">;
    }, "strict", z.ZodTypeAny, {
        data?: Record<string, import("../../..").JsonValue>[];
    }, {
        data?: Record<string, import("../../..").JsonValue>[];
    }>;
}, "strip", z.ZodTypeAny, {
    options?: {
        data?: Record<string, import("../../..").JsonValue>[];
    };
    type?: "json";
}, {
    options?: {
        data?: Record<string, import("../../..").JsonValue>[];
    };
    type?: "json";
}>, z.ZodObject<{
    type: z.ZodLiteral<"csv-file">;
    options: z.ZodObject<{
        path: z.ZodString;
        headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    } & {
        options: z.ZodOptional<z.ZodObject<{
            header: z.ZodOptional<z.ZodBoolean>;
            names: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
            delim: z.ZodOptional<z.ZodString>;
            quote: z.ZodOptional<z.ZodString>;
            escape: z.ZodOptional<z.ZodString>;
            comment: z.ZodOptional<z.ZodString>;
            skip: z.ZodOptional<z.ZodNumber>;
            nullstr: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>>;
            all_varchar: z.ZodOptional<z.ZodBoolean>;
            decimal_separator: z.ZodOptional<z.ZodString>;
            thousands: z.ZodOptional<z.ZodString>;
            encoding: z.ZodOptional<z.ZodString>;
            compression: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            header?: boolean;
            names?: string[];
            all_varchar?: boolean;
            delim?: string;
            quote?: string;
            escape?: string;
            comment?: string;
            decimal_separator?: string;
            thousands?: string;
            nullstr?: string | string[];
            skip?: number;
            encoding?: string;
            compression?: string;
        }, {
            header?: boolean;
            names?: string[];
            all_varchar?: boolean;
            delim?: string;
            quote?: string;
            escape?: string;
            comment?: string;
            decimal_separator?: string;
            thousands?: string;
            nullstr?: string | string[];
            skip?: number;
            encoding?: string;
            compression?: string;
        }>>;
    }, "strict", z.ZodTypeAny, {
        path?: string;
        options?: {
            header?: boolean;
            names?: string[];
            all_varchar?: boolean;
            delim?: string;
            quote?: string;
            escape?: string;
            comment?: string;
            decimal_separator?: string;
            thousands?: string;
            nullstr?: string | string[];
            skip?: number;
            encoding?: string;
            compression?: string;
        };
        headers?: Record<string, string>;
    }, {
        path?: string;
        options?: {
            header?: boolean;
            names?: string[];
            all_varchar?: boolean;
            delim?: string;
            quote?: string;
            escape?: string;
            comment?: string;
            decimal_separator?: string;
            thousands?: string;
            nullstr?: string | string[];
            skip?: number;
            encoding?: string;
            compression?: string;
        };
        headers?: Record<string, string>;
    }>;
}, "strip", z.ZodTypeAny, {
    options?: {
        path?: string;
        options?: {
            header?: boolean;
            names?: string[];
            all_varchar?: boolean;
            delim?: string;
            quote?: string;
            escape?: string;
            comment?: string;
            decimal_separator?: string;
            thousands?: string;
            nullstr?: string | string[];
            skip?: number;
            encoding?: string;
            compression?: string;
        };
        headers?: Record<string, string>;
    };
    type?: "csv-file";
}, {
    options?: {
        path?: string;
        options?: {
            header?: boolean;
            names?: string[];
            all_varchar?: boolean;
            delim?: string;
            quote?: string;
            escape?: string;
            comment?: string;
            decimal_separator?: string;
            thousands?: string;
            nullstr?: string | string[];
            skip?: number;
            encoding?: string;
            compression?: string;
        };
        headers?: Record<string, string>;
    };
    type?: "csv-file";
}>, z.ZodObject<{
    type: z.ZodLiteral<"json-file">;
    options: z.ZodObject<{
        path: z.ZodString;
        headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, "strict", z.ZodTypeAny, {
        path?: string;
        headers?: Record<string, string>;
    }, {
        path?: string;
        headers?: Record<string, string>;
    }>;
}, "strip", z.ZodTypeAny, {
    options?: {
        path?: string;
        headers?: Record<string, string>;
    };
    type?: "json-file";
}, {
    options?: {
        path?: string;
        headers?: Record<string, string>;
    };
    type?: "json-file";
}>, z.ZodObject<{
    type: z.ZodLiteral<"excel">;
    options: z.ZodObject<{
        path: z.ZodString;
        headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    } & {
        sheets: z.ZodOptional<z.ZodEffects<z.ZodArray<z.ZodObject<Pick<{
            sheet: z.ZodString;
            range: z.ZodOptional<z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, string, string>>;
            header: z.ZodDefault<z.ZodBoolean>;
            all_varchar: z.ZodOptional<z.ZodBoolean>;
            ignore_errors: z.ZodOptional<z.ZodBoolean>;
            stop_at_empty: z.ZodOptional<z.ZodBoolean>;
            empty_as_varchar: z.ZodOptional<z.ZodBoolean>;
        }, "header" | "sheet" | "range">, "strict", z.ZodTypeAny, {
            header?: boolean;
            sheet?: string;
            range?: string;
        }, {
            header?: boolean;
            sheet?: string;
            range?: string;
        }>, "atleastone">, [{
            header?: boolean;
            sheet?: string;
            range?: string;
        }, ...{
            header?: boolean;
            sheet?: string;
            range?: string;
        }[]], [{
            header?: boolean;
            sheet?: string;
            range?: string;
        }, ...{
            header?: boolean;
            sheet?: string;
            range?: string;
        }[]]>>;
    }, "strict", z.ZodTypeAny, {
        path?: string;
        headers?: Record<string, string>;
        sheets?: [{
            header?: boolean;
            sheet?: string;
            range?: string;
        }, ...{
            header?: boolean;
            sheet?: string;
            range?: string;
        }[]];
    }, {
        path?: string;
        headers?: Record<string, string>;
        sheets?: [{
            header?: boolean;
            sheet?: string;
            range?: string;
        }, ...{
            header?: boolean;
            sheet?: string;
            range?: string;
        }[]];
    }>;
}, "strip", z.ZodTypeAny, {
    options?: {
        path?: string;
        headers?: Record<string, string>;
        sheets?: [{
            header?: boolean;
            sheet?: string;
            range?: string;
        }, ...{
            header?: boolean;
            sheet?: string;
            range?: string;
        }[]];
    };
    type?: "excel";
}, {
    options?: {
        path?: string;
        headers?: Record<string, string>;
        sheets?: [{
            header?: boolean;
            sheet?: string;
            range?: string;
        }, ...{
            header?: boolean;
            sheet?: string;
            range?: string;
        }[]];
    };
    type?: "excel";
}>, z.ZodObject<{
    type: z.ZodLiteral<"parquet">;
    options: z.ZodObject<{
        path: z.ZodString;
        headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, "strict", z.ZodTypeAny, {
        path?: string;
        headers?: Record<string, string>;
    }, {
        path?: string;
        headers?: Record<string, string>;
    }>;
}, "strip", z.ZodTypeAny, {
    options?: {
        path?: string;
        headers?: Record<string, string>;
    };
    type?: "parquet";
}, {
    options?: {
        path?: string;
        headers?: Record<string, string>;
    };
    type?: "parquet";
}>]>, {
    options?: {
        csv?: string;
        options?: {
            header?: boolean;
            names?: string[];
            all_varchar?: boolean;
            delim?: string;
            quote?: string;
            escape?: string;
            comment?: string;
            decimal_separator?: string;
            thousands?: string;
            nullstr?: string | string[];
            skip?: number;
            encoding?: string;
            compression?: string;
        };
    };
    type?: "csv";
} | {
    options?: {
        data?: Record<string, import("../../..").JsonValue>[];
    };
    type?: "json";
} | {
    options?: {
        path?: string;
        options?: {
            header?: boolean;
            names?: string[];
            all_varchar?: boolean;
            delim?: string;
            quote?: string;
            escape?: string;
            comment?: string;
            decimal_separator?: string;
            thousands?: string;
            nullstr?: string | string[];
            skip?: number;
            encoding?: string;
            compression?: string;
        };
        headers?: Record<string, string>;
    };
    type?: "csv-file";
} | {
    options?: {
        path?: string;
        headers?: Record<string, string>;
    };
    type?: "json-file";
} | {
    options?: {
        path?: string;
        headers?: Record<string, string>;
        sheets?: [{
            header?: boolean;
            sheet?: string;
            range?: string;
        }, ...{
            header?: boolean;
            sheet?: string;
            range?: string;
        }[]];
    };
    type?: "excel";
} | {
    options?: {
        path?: string;
        headers?: Record<string, string>;
    };
    type?: "parquet";
}, {
    options?: {
        csv?: string;
        options?: {
            header?: boolean;
            names?: string[];
            all_varchar?: boolean;
            delim?: string;
            quote?: string;
            escape?: string;
            comment?: string;
            decimal_separator?: string;
            thousands?: string;
            nullstr?: string | string[];
            skip?: number;
            encoding?: string;
            compression?: string;
        };
    };
    type?: "csv";
} | {
    options?: {
        data?: Record<string, import("../../..").JsonValue>[];
    };
    type?: "json";
} | {
    options?: {
        path?: string;
        options?: {
            header?: boolean;
            names?: string[];
            all_varchar?: boolean;
            delim?: string;
            quote?: string;
            escape?: string;
            comment?: string;
            decimal_separator?: string;
            thousands?: string;
            nullstr?: string | string[];
            skip?: number;
            encoding?: string;
            compression?: string;
        };
        headers?: Record<string, string>;
    };
    type?: "csv-file";
} | {
    options?: {
        path?: string;
        headers?: Record<string, string>;
    };
    type?: "json-file";
} | {
    options?: {
        path?: string;
        headers?: Record<string, string>;
        sheets?: [{
            header?: boolean;
            sheet?: string;
            range?: string;
        }, ...{
            header?: boolean;
            sheet?: string;
            range?: string;
        }[]];
    };
    type?: "excel";
} | {
    options?: {
        path?: string;
        headers?: Record<string, string>;
    };
    type?: "parquet";
}>;
/** Return table metadata through the same bounded ExecutionResult protocol as queries. */
export declare const SCHEMA_CODE = "import numpy as np\n\ndef field_type(series):\n    dtype = str(series.dtype)\n    if not pd.api.types.is_object_dtype(series.dtype):\n        return dtype\n\n    observed = set()\n    has_arrays = False\n    # Bounded observations describe actual cell containers, not an exhaustive schema.\n    for value in series.dropna().head(32):\n        kind = type(value).__module__ + '.' + type(value).__name__\n        if isinstance(value, (np.ndarray, list, tuple)):\n            has_arrays = True\n            items = pd.api.types.infer_dtype(list(value)[:32], skipna=True)\n            kind += '[items: ' + items + ']'\n        observed.add(kind)\n\n    return dtype + ' (observed cell types, up to 32 non-null cells: ' + ', '.join(sorted(observed)) + ')' if has_arrays else dtype\n\nresult = [\n    {'name': name, 'tableReference': {'table': name},\n     'columns': [{'name': column, 'type': field_type(frame[column])} for column in frame.columns]}\n    for name, frame in tables.items()\n]";
export declare const tableSchema: z.ZodEffects<z.ZodObject<{
    name: z.ZodString;
    tableReference: z.ZodObject<{
        table: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        table?: string;
    }, {
        table?: string;
    }>;
    columns: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        type: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        name?: string;
        type?: string;
    }, {
        name?: string;
        type?: string;
    }>, "many">;
}, "strip", z.ZodTypeAny, {
    name?: string;
    columns?: {
        name?: string;
        type?: string;
    }[];
    tableReference?: {
        table?: string;
    };
}, {
    name?: string;
    columns?: {
        name?: string;
        type?: string;
    }[];
    tableReference?: {
        table?: string;
    };
}>, {
    name?: string;
    columns?: {
        name?: string;
        type?: string;
    }[];
    tableReference?: {
        table?: string;
    };
}, {
    name?: string;
    columns?: {
        name?: string;
        type?: string;
    }[];
    tableReference?: {
        table?: string;
    };
}>;
