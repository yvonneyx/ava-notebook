import type { DataSourceConfig, ExecutionOptions } from '../../../types';
/** Assemble source loading, analysis and bounded JSON output into one executable script. */
export declare function executionCode(code: string, source: DataSourceConfig, limits: ExecutionOptions): string;
