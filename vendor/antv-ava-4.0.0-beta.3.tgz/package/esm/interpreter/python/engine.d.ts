/** Python engine: pandas analysis through a local or caller-supplied executor. */
import type { AnalysisEngine, DataModel, DataSourceConfig, ExecutionOptions, ExecutionResult, LLMConfig, Profile, ProfileOptions, PythonEngineOptions, Schema } from '../../types';
export declare class PythonEngine implements AnalysisEngine {
    private readonly llmConfig;
    readonly language: {
        name: string;
        fence: string;
        instructions: string;
    };
    private source;
    private readonly timeoutMs;
    private readonly executor;
    constructor(llmConfig: LLMConfig, engineOptions?: PythonEngineOptions);
    load(config: DataSourceConfig): Promise<void>;
    schema(): Promise<Schema>;
    getDSL(query: string, dataModel: DataModel): Promise<string>;
    profile(schema: Schema, options?: ProfileOptions): Promise<Profile>;
    execute<T = Record<string, unknown>>(code: string, options?: ExecutionOptions): Promise<ExecutionResult<T>>;
    private metadata;
    dispose(): Promise<void>;
}
