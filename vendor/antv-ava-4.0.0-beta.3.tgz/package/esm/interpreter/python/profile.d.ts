import type { Metric, ParsedProfileOptions, Schema } from '../../types';
/** Python expressions receive the same per-target context as JavaScript interpreter metrics. */
export declare const BUILTIN_METRICS: Metric<string>[];
/** Build fixed pandas statistics; only metadata is returned to AVA. */
export declare function profileCode(options: ParsedProfileOptions, schema: Schema): string;
