import type { JsonValue, Metric, ParsedProfileOptions, Profile, Schema } from '../../types';
interface Context {
    rowCount: number;
    values: unknown[];
    numbers: number[];
    distinct: Map<unknown, number>;
    metric: ParsedProfileOptions['metrics'][number];
}
type InterpreterMetric = Metric<(context: Context) => JsonValue | undefined>;
export declare const BUILTIN_METRICS: InterpreterMetric[];
export declare function profileTables(data: Record<string, unknown>[], schema: Schema, options: ParsedProfileOptions): Profile;
export {};
