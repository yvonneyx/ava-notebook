/**
 * Inline CSV loader: parse raw CSV content into rows.
 */
import type { CSVSourceOptions } from '../../../types';
export declare function loadCSV(options: CSVSourceOptions): Promise<any[]>;
