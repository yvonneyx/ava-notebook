/**
 * Data source loaders for the JavaScript interpreter engine.
 */
import type { CSVSourceOptions, JsonSourceOptions, LLMConfig, TextSourceOptions } from '../../../types';
export type InterpreterSourceConfig = {
    type: 'csv';
    options: CSVSourceOptions;
} | {
    type: 'json';
    options: JsonSourceOptions;
} | {
    type: 'text';
    options: TextSourceOptions;
};
export declare function loadSource(config: InterpreterSourceConfig, llmConfig: LLMConfig): Promise<any[]>;
