/**
 * JSON loader: validate an in-memory object array.
 */
import type { JsonSourceOptions } from '../../../types';
export declare function loadJson(options: JsonSourceOptions): Promise<any[]>;
