/**
 * Text loader: extract structured data from unstructured text via LLM.
 */
import type { LLMConfig, TextSourceOptions } from '../../../types';
export declare function loadText(options: TextSourceOptions, llmConfig: LLMConfig): Promise<any[]>;
