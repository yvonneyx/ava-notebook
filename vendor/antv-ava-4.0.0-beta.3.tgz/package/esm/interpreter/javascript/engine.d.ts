/**
 * Interpreter engine: LLM generates JavaScript, executed against in-memory data.
 *
 * Unlike the DuckDB engine, this engine keeps data as a plain JS array and
 * executes LLM-generated code directly in a sandbox. It is lightweight and
 * browser-friendly, but only supports csv/json/text sources.
 */
import type { Profile, ProfileOptions, AnalysisEngine, DataModel, DataSourceConfig, LLMConfig, Schema, ExecutionOptions, ExecutionResult } from '../../types';
export declare class JavaScriptEngine implements AnalysisEngine {
    private readonly llmConfig;
    readonly language: {
        name: string;
        fence: string;
    };
    private data;
    constructor(llmConfig: LLMConfig);
    load(config: DataSourceConfig): Promise<void>;
    schema(): Promise<Schema>;
    /**
     * Return the loaded in-memory rows (null when nothing is loaded).
     * Only the JavaScript interpreter engine keeps data as a plain single-table array,
     * so it is the only engine that can expose it directly.
     */
    getData(): any[] | null;
    profile(schema: Schema, options?: ProfileOptions): Promise<Profile>;
    getDSL(query: string, dataModel: DataModel): Promise<string>;
    execute<T = Record<string, unknown>>(code: string, options?: ExecutionOptions): Promise<ExecutionResult<T>>;
    dispose(): Promise<void>;
}
