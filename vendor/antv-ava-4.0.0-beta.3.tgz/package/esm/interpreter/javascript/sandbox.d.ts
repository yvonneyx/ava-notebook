/**
 * Execute LLM-generated JavaScript analysis code.
 */
/**
 * Execute analysis code with data and stat helpers.
 * The code must assign its final output to a variable named `result`.
 */
export declare function executeCode(data: any[], code: string): Promise<any>;
