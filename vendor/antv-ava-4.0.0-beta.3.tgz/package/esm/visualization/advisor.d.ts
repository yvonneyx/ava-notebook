/**
 * Chart type advisor: recommend a chart type from the query and a
 * pre-formatted data description string.
 */
import type { LLMConfig, ChartType } from '../types';
/**
 * Advise appropriate chart type based on user query and pre-formatted data info.
 *
 * @param query - The user's natural language query
 * @param dataInfoStr - Pre-formatted data description string
 * @param llmConfig - LLM configuration
 * @returns Recommended ChartType, or null if no visualization is needed
 */
export declare function adviseChartType(query: string, dataInfoStr: string, llmConfig: LLMConfig): Promise<ChartType | null>;
