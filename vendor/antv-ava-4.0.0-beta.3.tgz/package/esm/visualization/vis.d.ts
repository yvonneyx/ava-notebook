/**
 * Chart definitions metadata
 */
import type { ChartTypeDefinition } from '../types';
declare const chartDefinitions: ChartTypeDefinition[];
export { chartDefinitions };
