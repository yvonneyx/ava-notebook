/**
 * GPT-Vis visualization generator
 *
 * Strategy: LLM only generates a GPT-Vis JSON config, then we wrap it
 * into an HTML template locally. This avoids unreliable regex extraction
 * from LLM-generated HTML and ensures the HTML is always well-formed.
 */
import type { LLMConfig, ChartType, ChartConfig } from '../types';
/**
 * Wrap a GPT-Vis JSON config into a standalone HTML file that can be opened in any browser
 */
export declare function wrapConfigInHTML(config: ChartConfig): string;
/**
 * Generate a GPT-Vis JSON config for the chart type, data, and user query.
 */
export declare function generateVisualizationConfig(chartType: ChartType, data: any, query: string, llmConfig: LLMConfig): Promise<ChartConfig>;
