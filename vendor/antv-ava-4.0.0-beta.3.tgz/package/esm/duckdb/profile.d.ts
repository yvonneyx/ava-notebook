import type { MetricField } from '../util/profile';
import type { DuckDBConnection, Schema, ParsedProfileOptions, LogicalType, Metric, Profile } from '../types';
/** Map a database type to a profile type. */
export declare function logicalType(nativeType: string): LogicalType;
interface ExpressionContext {
    readonly table: string;
    readonly column?: string;
    readonly field?: MetricField;
    readonly metric: ParsedProfileOptions['metrics'][number];
}
export type DuckDBMetricExpression = (context: ExpressionContext) => string;
export type DuckDBMetric = Metric<DuckDBMetricExpression>;
export declare const BUILTIN_METRICS: DuckDBMetric[];
export { DEFAULT_METRICS } from '../util/profile';
/** Compute requested metrics for each model and column. */
export declare function profileTables(connection: DuckDBConnection, schema: Schema, options: ParsedProfileOptions): Promise<Profile>;
