/**
 * DuckDB engine: LLM generates SQL, executed against an in-memory DuckDB instance.
 */
import type { AnalysisEngine, Profile, ProfileOptions, DataModel, DataSourceConfig, DuckDBEngineOptions, Schema, LLMConfig, ExecutionOptions, ExecutionResult } from '../types';
/** Thrown when a query exceeds the configured timeout. */
export declare class QueryTimeoutError extends Error {
    constructor(timeoutMs: number);
}
export declare class DuckDBEngine implements AnalysisEngine {
    private readonly llmConfig;
    private readonly engineOptions;
    readonly language: {
        name: string;
        fence: string;
    };
    private instance;
    private connection;
    private source;
    private readonly queryDialect;
    private allowCommunityExtensions;
    constructor(llmConfig: LLMConfig, engineOptions?: DuckDBEngineOptions);
    /**
     * Get or create the DuckDB connection (lazy loading)
     */
    private getConnection;
    /**
     * Harden the session after the data view is registered: whitelist the data
     * file's directories, then disable further external access and lock the
     * configuration so LLM-generated SQL cannot read arbitrary files or undo it.
     */
    private restrictAccess;
    load(config: DataSourceConfig): Promise<void>;
    schema(): Promise<Schema>;
    profile(schema: Schema, options?: ProfileOptions): Promise<Profile>;
    getDSL(query: string, dataModel: DataModel): Promise<string>;
    execute<T = Record<string, unknown>>(sql: string, options?: ExecutionOptions): Promise<ExecutionResult<T>>;
    /**
     * Close the database connection and instance
     */
    private close;
    dispose(): Promise<void>;
}
