/**
 * MySQL loader: ATTACH a MySQL database through DuckDB's mysql extension and
 * register one view per table in the database. Supports an optional SSH tunnel.
 * https://duckdb.org/docs/lts/core_extensions/mysql
 */
import type { MySQLSourceOptions, LoadedSource } from '../../types';
export declare function loadMySQL(options: MySQLSourceOptions): Promise<LoadedSource>;
