/**
 * Inline CSV loader: parse raw CSV content into rows, then re-serialize to a
 * temp CSV file for DuckDB to read. (For CSV files use the csv-file loader.)
 */
import type { CSVSourceOptions, LoadedSource } from '../../types';
export declare function loadCSV(loaderOptions: CSVSourceOptions): Promise<LoadedSource>;
