/**
 * PostgreSQL loader: ATTACH a PostgreSQL database through DuckDB's postgres
 * extension and register one view per table in the schema. Supports an optional SSH tunnel.
 * https://duckdb.org/docs/lts/core_extensions/postgres
 */
import type { PostgreSQLSourceOptions, LoadedSource } from '../../types';
export declare function loadPostgreSQL(options: PostgreSQLSourceOptions): Promise<LoadedSource>;
