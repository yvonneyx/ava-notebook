import type { LoadedSource, SQLiteSourceOptions } from '../../types';
export declare function loadSQLite(options: SQLiteSourceOptions): Promise<LoadedSource>;
