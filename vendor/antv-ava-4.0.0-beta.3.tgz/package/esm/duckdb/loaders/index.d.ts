/**
 * Data source loaders: turn a DataSourceConfig into a LoadedSource
 * that the engine registers as one or more views.
 */
import type { DataSourceConfig, LLMConfig, LoadedSource } from '../../types';
export type { LoadedSource } from '../../types';
/**
 * Load a data source config into a LoadedSource the engine can register.
 */
export declare function loadSource(config: DataSourceConfig, llmConfig: LLMConfig): Promise<LoadedSource>;
