/**
 * JSON loader: validate an in-memory object array and write it to a temp JSON
 * file for DuckDB to read.
 */
import type { JsonSourceOptions, LoadedSource } from '../../types';
export declare function loadJson(options: JsonSourceOptions): Promise<LoadedSource>;
