import type { FeishuApi } from './api';
import type { BitableRef } from './url';
export interface BitableSourceOptions {
    url?: string;
    appToken?: string;
    tableId?: string;
}
/**
 * Resolve a Feishu source to the Bitable app token and table ID the API needs.
 *
 * `/base/<appToken>` links already carry the app token, while `/wiki/<nodeToken>`
 * links carry a wiki node token whose hosted object has to be looked up first.
 * Either link may omit `?table=` when the Bitable has exactly one table.
 */
export declare function resolveBitableTable(options: BitableSourceOptions, api: FeishuApi): Promise<BitableRef>;
