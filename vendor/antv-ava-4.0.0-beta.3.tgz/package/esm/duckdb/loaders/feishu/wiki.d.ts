import type { FeishuApi } from './api';
export interface WikiNode {
    objToken: string;
    objType: string;
    title: string;
}
/**
 * Resolve a `/wiki/<nodeToken>` link to the object the node hosts.
 *
 * The app needs wiki read access and wiki space membership, which is separate
 * from the document grant on the hosted table.
 */
export declare function resolveWikiNode(wikiToken: string, api: FeishuApi): Promise<WikiNode>;
