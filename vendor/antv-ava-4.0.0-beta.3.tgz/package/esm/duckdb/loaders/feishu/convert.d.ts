export type FeishuCell = string | number | boolean | null;
export declare enum FeishuFieldType {
    Text = 1,
    Number = 2,
    SingleSelect = 3,
    MultiSelect = 4,
    DateTime = 5,
    Checkbox = 7,
    User = 11,
    Phone = 13,
    Url = 15,
    Attachment = 17,
    SingleLink = 18,
    Lookup = 19,
    Formula = 20,
    DuplexLink = 21,
    Location = 22,
    GroupChat = 23,
    Stage = 24,
    CreatedTime = 1001,
    ModifiedTime = 1002,
    CreatedUser = 1003,
    ModifiedUser = 1004,
    AutoNumber = 1005,
    Button = 3001
}
export declare function isSupportedFieldType(type: number): boolean;
export declare function asString(value: unknown): string | null;
export declare function asMultiSelect(value: unknown): string | null;
export declare function asCheckbox(value: unknown): boolean | null;
export declare function asText(value: unknown): string | null;
export declare function asPhone(value: unknown): string | null;
export declare function asSingleSelect(value: unknown): string | null;
export declare function asNumber(value: unknown): number | null;
export declare function asTimestamp(value: unknown): string | null;
export declare function asUrl(value: unknown): string | null;
export declare function asAutoNumber(value: unknown): string | null;
/** 人员、创建人、修改人：取人员名称，多个用逗号拼接。 */
export declare function asUser(value: unknown): string | null;
/** 附件：取文件名，多个用逗号拼接。 */
export declare function asAttachment(value: unknown): string | null;
/** 单向/双向关联：取关联记录 ID，多个用逗号拼接。 */
export declare function asLink(value: unknown): string | null;
/** 地理位置：优先完整地址，其次地名、详细地址、经纬度。 */
export declare function asLocation(value: unknown): string | null;
/** 群组：取群组名称，多个用逗号拼接。 */
export declare function asGroupChat(value: unknown): string | null;
/** 查找引用/公式：按包内 type 递归转换结果。 */
export declare function asFormula(value: unknown): FeishuCell;
export declare function convertFieldValue(type: number, value: unknown): FeishuCell;
export interface FeishuField {
    name: string;
    type: number;
}
export declare function convertRecord(fields: FeishuField[], record: Record<string, unknown>): Record<string, FeishuCell>;
