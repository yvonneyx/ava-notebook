export interface FeishuApi {
    token: string;
    origin: string;
}
/**
 * GET a Feishu Open API endpoint with a tenant access token and unwrap `data`.
 */
export declare function feishuGet(url: string, token: string): Promise<Record<string, unknown>>;
