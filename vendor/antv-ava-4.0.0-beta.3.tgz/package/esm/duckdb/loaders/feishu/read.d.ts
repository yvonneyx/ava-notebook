import type { FeishuCell, FeishuField } from "./convert";
import type { FeishuBitableSourceOptions } from "../../../types";
export declare function readFeishuTable(options: FeishuBitableSourceOptions): Promise<{
    fields: FeishuField[];
    rows: Record<string, FeishuCell>[];
}>;
export declare function readTable(options: FeishuBitableSourceOptions): Promise<Record<string, FeishuCell>[]>;
