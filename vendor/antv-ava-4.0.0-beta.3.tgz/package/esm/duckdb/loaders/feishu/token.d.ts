export declare function feishuOrigin(url?: string): string;
export declare function feishuError(code: unknown, msg: unknown): Error;
export declare function getTenantAccessToken(appId: string, appSecret: string, origin?: string): Promise<string>;
