export interface BitableRef {
    appToken: string;
    tableId: string;
}
/**
 * A Feishu link that points at a Bitable, either directly (`/base/<appToken>`) or
 * through a wiki node (`/wiki/<nodeToken>`). A wiki token is a node token, not the
 * app token, so it has to be resolved before the Bitable API can be used.
 */
export interface FeishuTableLink {
    kind: 'base' | 'wiki';
    token: string;
    tableId?: string;
}
export declare function parseTableLink(input: string): FeishuTableLink | undefined;
/**
 * Parse a `/base/` link that names its table, e.g. `/base/<appToken>?table=<tableId>`.
 */
export declare function parseBitableUrl(input: string): BitableRef;
