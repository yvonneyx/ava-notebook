/**
 * Text loader: extract structured data from unstructured text via LLM,
 * then write it to a temp JSON file for DuckDB to read.
 */
import type { LLMConfig, TextSourceOptions, LoadedSource } from '../../types';
export declare function loadText(options: TextSourceOptions, llmConfig: LLMConfig): Promise<LoadedSource>;
