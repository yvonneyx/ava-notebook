/**
 * Parquet file loader: read a Parquet file (local path or http(s) URL) through
 * DuckDB's parquet reader.
 */
import type { ParquetSourceOptions } from '../../types';
export declare const loadParquetFile: (loaderOptions: ParquetSourceOptions) => Promise<import("../../types").LoadedSource>;
