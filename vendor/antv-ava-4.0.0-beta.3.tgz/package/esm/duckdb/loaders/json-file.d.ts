/**
 * JSON file loader: read a JSON file (local path or http(s) URL) through
 * DuckDB's json reader. Distinct from the inline `json` loader (json.ts),
 * which takes an in-memory object array.
 */
import type { JsonFileSourceOptions } from '../../types';
export declare const loadJSONFile: (loaderOptions: JsonFileSourceOptions) => Promise<import("../../types").LoadedSource>;
