import type { FeishuBitableSourceOptions, LoadedSource } from '../../types';
export declare function loadFeishuBitable(options: FeishuBitableSourceOptions): Promise<LoadedSource>;
