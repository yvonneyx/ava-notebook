/**
 * Excel loader: read an .xlsx workbook (local path or http(s) URL) through
 * DuckDB's excel extension, registering one view per sheet.
 * https://duckdb.org/docs/current/core_extensions/excel
 */
import type { ExcelSourceOptions, LoadedSource } from '../../types';
export declare function loadExcel(options: ExcelSourceOptions): Promise<LoadedSource>;
