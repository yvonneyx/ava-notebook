/**
 * File helpers for the DuckDB engine: temp file creation, remote download,
 * cleanup, and the shared file-source helpers used by the file-based loaders
 * (csv-file, json-file, parquet). A local file path is used directly; a remote
 * URL is downloaded to a temp file first. Node.js only.
 */
import type { CSVReadOptions, JSONReadOptions, FileFormat, LoadedSource } from '../../types';
/** Write content to a unique temp file and return its path */
export declare function writeTempFile(content: string | Buffer, ext: string): Promise<string>;
/** Download a remote URL to a temp file and return its path */
export declare function downloadToTempFile(url: string, ext: string, headers?: Record<string, string>): Promise<string>;
/** Delete a temp file, ignoring errors */
export declare function removeTempFile(filePath: string): Promise<void>;
/**
 * Build a LoadedSource that registers a local file as the single `data` view.
 * The view reads the file lazily, so the file must outlive the engine.
 * The file's directory is whitelisted so the engine can still read it after hardening.
 * `options` carries extra DuckDB reader options (applied to CSV and JSON readers).
 */
export declare function fileSource(path: string, format: FileFormat, cleanup: () => Promise<void>, options?: CSVReadOptions | JSONReadOptions): LoadedSource;
/**
 * Structural shape shared by every file-source options type
 * (CSVFileSourceOptions / JsonFileSourceOptions / ParquetSourceOptions).
 * Each loader declares its own options interface; this constraint lets them
 * reuse one implementation while keeping their types distinct.
 */
export interface FileLoaderOptions {
    /** Local file path or http(s) URL */
    path: string;
    /** HTTP headers for remote sources (e.g. Authorization) */
    headers?: Record<string, string>;
    /** Extra DuckDB reader options (applied to CSV and JSON readers) */
    options?: CSVReadOptions | JSONReadOptions;
}
/**
 * Build a file loader for a DuckDB-readable format: local files are read in
 * place, remote URLs are downloaded to a temp file first.
 */
export declare function createFileLoader<T extends FileLoaderOptions>(format: FileFormat): (loaderOptions: T) => Promise<LoadedSource>;
