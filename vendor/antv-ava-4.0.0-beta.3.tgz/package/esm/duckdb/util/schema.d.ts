import type { DuckDBConnection, Schema } from '../../types';
/** Read the current namespace; an empty scope skips querying. */
export declare function getDuckDBSchema(conn: DuckDBConnection, tableNames?: string[]): Promise<Schema>;
