/**
 * SSH tunnel helper for database loaders: forward a local port to the target
 * database server through SSH, so DuckDB can ATTACH to 127.0.0.1:localPort.
 */
import type { SSHOptions } from '../../types';
export interface SSHTunnel {
    localPort: number;
    close: () => Promise<void>;
}
/** Forward a local port to the target host:port through SSH */
export declare function createSshTunnel(ssh: SSHOptions, targetHost: string, targetPort: number): Promise<SSHTunnel>;
