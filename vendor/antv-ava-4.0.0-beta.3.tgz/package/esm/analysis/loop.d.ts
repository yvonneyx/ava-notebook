import type { AnalysisStrategy } from '../types';
/**
 * Explore, refine, execute, and verify SQL before returning an answer.
 */
export declare const loopAnalysis: AnalysisStrategy;
