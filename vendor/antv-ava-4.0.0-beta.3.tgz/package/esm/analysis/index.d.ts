import type { AnalysisConfig, AnalysisResponse, AnalysisRuntime } from '../types';
export declare function analyze(query: string, config: AnalysisConfig, runtime: AnalysisRuntime): Promise<AnalysisResponse>;
