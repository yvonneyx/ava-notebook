import type { AnalysisStrategy } from '../types';
export declare const directAnalysis: AnalysisStrategy;
