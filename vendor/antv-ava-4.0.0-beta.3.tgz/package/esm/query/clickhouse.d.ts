import type { ClickHouseClient } from '@clickhouse/client';
import type { DataModel, LLMConfig, QueryDialect } from '../types';
export declare class ClickHouseQueryDialect implements QueryDialect<ClickHouseClient> {
    private readonly llmConfig;
    constructor(llmConfig: LLMConfig);
    getDSL(query: string, dataModel: DataModel): Promise<string>;
    /** Parse and normalize on the server; SQL is a parameter, never an executable suffix.
     * formatQuery rejects invalid/multiple statements and removes comments/terminators.
     * Parsing the normalized SQL as a subquery excludes DDL/DML and output clauses.
     * https://clickhouse.com/docs/sql-reference/functions/other-functions#formatQuery
     * https://clickhouse.com/docs/sql-reference/statements/select#syntax
     */
    validateDSL(sql: string, client: ClickHouseClient): Promise<string>;
}
