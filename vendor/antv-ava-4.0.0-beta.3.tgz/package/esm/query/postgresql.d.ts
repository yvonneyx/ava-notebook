import type { LLMConfig, QueryDialect, DataModel } from '../types';
export declare class PostgreSQLQueryDialect implements QueryDialect {
    private readonly llmConfig;
    private readonly parser;
    constructor(llmConfig: LLMConfig);
    getDSL(query: string, dataModel: DataModel): Promise<string>;
    validateDSL(sql: string): Promise<string>;
}
