import type { LLMConfig, DataModel } from '../types';
export declare function generateDuckDBSQL(query: string, dataModel: DataModel, llmConfig: LLMConfig): Promise<string>;
