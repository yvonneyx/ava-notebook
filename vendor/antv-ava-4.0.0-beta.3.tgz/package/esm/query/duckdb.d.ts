import type { DuckDBConnection } from '@duckdb/node-api';
import type { LLMConfig, QueryDialect, DataModel } from '../types';
export declare class DuckDBQueryDialect implements QueryDialect<DuckDBConnection> {
    private readonly llmConfig;
    constructor(llmConfig: LLMConfig);
    getDSL(query: string, dataModel: DataModel): Promise<string>;
    validateDSL(sql: string, connection: DuckDBConnection): Promise<string>;
}
