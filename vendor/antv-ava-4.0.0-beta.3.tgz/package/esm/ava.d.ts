/**
 * AVA v4 - A framework for AI-native Visual Analytics
 */
import EventEmitter from '@antv/event-emitter';
import type { AVAConfig, DataSourceConfig, SchemaOptions, SemanticOptions, Semantic, Schema, AnalysisEngine, AnalysisResponse, AnalysisConfig, VisualizeResponse, ChartSpec, SuggestResult, Profile, ProfileOptions, ExecutionOptions, ExecutionResult } from './types';
/**
 * Main AVA class for AI-native visual analytics.
 * Data loading and analysis are backed by a pluggable engine — natural-language
 * queries are turned into SQL via LLM and executed by the configured engine.
 */
export declare class AVA extends EventEmitter {
    private readonly llmConfig;
    private readonly engineConfig;
    engine: AnalysisEngine | null;
    private dataSchema;
    private dataProfile;
    private dataSemantic;
    constructor(config: AVAConfig);
    /** Assemble the dataset model when a model-facing operation needs it. */
    private getDataModel;
    /**
     * Instantiate the engine selected by the engine config.
     * Engine classes are registered by the entry point (index.ts /
     * index.browser.ts), so this class never imports any engine implementation
     * directly — Node-only engines stay out of browser bundles.
     */
    private createEngine;
    /**
     * Release the current engine, including replacement and failed-load cleanup.
     */
    private disposeEngine;
    /**
     * Load a data source config into the engine.
     * Reloading disposes the previous engine and its resources.
     */
    source(config: DataSourceConfig): Promise<void>;
    /**
     * Describe the data source structure.
     * Include tables, fields, types, indexes, and relations.
     */
    schema(options?: SchemaOptions, setter?: (options: SchemaOptions) => Schema): Promise<Schema>;
    /**
     * Compute a statistical profile of the data source.
     */
    profile(options?: ProfileOptions, setter?: (options: ProfileOptions) => Profile): Promise<Profile>;
    /** Read or replace semantic definitions used in model-facing operations. */
    semantic(options?: SemanticOptions, setter?: (options: SemanticOptions) => Semantic): Promise<Semantic>;
    /**
     * Analyze data using natural language query.
     * The query is turned into SQL via LLM and executed by the configured engine.
     * Use visualize() separately to generate charts from the analysis result.
     */
    analyze(query: string, config?: AnalysisConfig): Promise<AnalysisResponse>;
    /**
     * Translate a natural-language query into DSL.
     * Use query() to execute the generated DSL.
     */
    translate(query: string): Promise<string>;
    /**
     * Execute a read-only query against the data source.
     * The DSL must match the current engine's query language.
     */
    query(dsl: string, options?: ExecutionOptions): Promise<ExecutionResult>;
    /**
     * Visualize analysis data by recommending a chart type and generating chart HTML.
     * Accepts the result from analyze() — the query and data are read from it.
     *
     * @param analysisResult - The result returned from analyze()
     * @returns VisualizeResponse, or null if no chart is needed. Generation errors propagate to the caller.
     */
    visualize(analysisResult: Pick<AnalysisResponse, 'query' | 'data'>): Promise<VisualizeResponse | null>;
    /**
     * Recommend a chart specification for the analysis result.
     * Combine a suitable chart type with GPT-Vis JSON config for rendering.
     */
    recommend(analysisResult: Pick<AnalysisResponse, 'query' | 'data'>): Promise<ChartSpec | null>;
    /**
     * Render a chart specification as standalone HTML.
     */
    viz(spec: ChartSpec): Promise<string>;
    /**
     * Suggest questions about the loaded data.
     */
    suggest(count?: number): Promise<SuggestResult[]>;
    /**
     * Clean up resources (engine storage, temp files)
     */
    dispose(): Promise<void>;
}
