export declare const description = "Release the dataset and its process";
export declare const definition: {
    readonly positionals: 1;
    readonly options: {};
};
export declare function run([datasetId]: string[]): Promise<unknown>;
export declare const help = "Release the dataset and its process.\n\nUsage:\n  ava dispose <dataset-id>\n\nUse the datasetId returned by ava source.\nThe ID becomes invalid after disposal. Load the source again to get a new ID.\n\nOptions:\n  -h, --help  Show help.\n\nExample:\n  ava dispose ds_...";
