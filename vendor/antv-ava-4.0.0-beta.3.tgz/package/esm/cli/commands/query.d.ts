import type { Options } from '../options';
export declare const description = "Execute a query in the dataset engine's language";
export declare const definition: {
    readonly positionals: 1;
    readonly options: {
        readonly dsl: {
            readonly type: "string";
        };
        readonly 'max-rows': {
            readonly type: "string";
        };
        readonly 'max-result-bytes': {
            readonly type: "string";
        };
    };
};
export declare function run([datasetId]: string[], options: Options): Promise<unknown>;
export declare const help = "Execute a query in the dataset engine's language.\n\nUsage:\n  ava query <dataset-id> --dsl <code|@file|-> [options]\n\nUse the datasetId returned by ava source. Returns query results as JSON.\nUse ava schema to find the query language, table and field names. No API key is required.\nSQL engines require a read-only SELECT; Python/JavaScript execute analysis code.\nLocal Python execution is not sandboxed. Engine selection is fixed by ava source.\n\nOptions:\n  --dsl <code|@file|->     Required SQL, Python or JavaScript, @file, or - for stdin (max: 512 KiB).\n  --max-rows <n>          Maximum result rows, 1-10000 (default: 200).\n  --max-result-bytes <n>  Positive integer byte limit for result data\n                         (default: 1048576, or 1 MiB).\n  -h, --help              Show help.\n\nExamples:\n  ava query ds_... --dsl 'SELECT 1 AS value'\n  ava query ds_... --dsl @query.sql";
