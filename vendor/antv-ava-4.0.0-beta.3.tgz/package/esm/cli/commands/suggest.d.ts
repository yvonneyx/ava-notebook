import type { Options } from '../options';
export declare const description = "Suggest analysis questions";
export declare const definition: {
    readonly positionals: 1;
    readonly options: {
        readonly count: {
            readonly type: "string";
        };
    };
};
export declare function run([datasetId]: string[], options: Options): Promise<unknown>;
export declare const help = "Suggest analysis questions.\n\nUsage:\n  ava suggest <dataset-id> [options]\n\nUse the datasetId returned by ava source.\nRequires OPENAI_API_KEY to have been set before loading that dataset.\n\nOptions:\n  --count <n>  Number of questions, 1-100 (default: 3).\n  -h, --help   Show help.\n\nExample:\n  ava suggest ds_... --count 5";
