import type { Options } from '../options';
export declare const description = "Compute dataset statistics";
export declare const definition: {
    readonly positionals: 1;
    readonly options: {
        readonly metrics: {
            readonly type: "string";
        };
        readonly file: {
            readonly type: "string";
        };
    };
};
export declare function run([datasetId]: string[], options: Options): Promise<unknown>;
export declare const help = "Compute dataset statistics.\n\nUsage:\n  ava profile <dataset-id> [options]\n\nUse the datasetId returned by ava source.\nReturns a JSON profile and retains it for subsequent analysis commands.\n\nOptions:\n  --file <path>    Set the profile from a JSON file instead of computing it.\n                   Cannot be combined with --metrics. Does not replace schema.\n  --metrics <list>  Comma-separated metric names; replaces the defaults.\n                   Use --metrics \"\" for structure without statistics.\n  -h, --help        Show help.\n\nDefault metrics:\n  row_count, null_count, distinct_count, top_values, min, max, mean\n\nAdditional metrics:\n  duplicate_count, min_length, max_length, sum, stddev, median\n  Metrics apply only to compatible fields.\n\nExample:\n  ava profile ds_... --metrics row_count,null_count,mean\n  ava profile ds_... --file profile.json";
