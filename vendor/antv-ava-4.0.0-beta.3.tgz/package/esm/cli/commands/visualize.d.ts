import type { Options } from '../options';
export declare const description = "Generate a chart from query and data";
export declare const definition: {
    readonly positionals: 0;
    readonly options: {
        readonly query: {
            readonly type: "string";
        };
        readonly data: {
            readonly type: "string";
        };
        readonly output: {
            readonly type: "string";
            readonly short: "o";
        };
    };
};
export declare function run(_args: string[], options: Options): Promise<unknown>;
export declare const help = "Generate a chart from query and data.\n\nUsage:\n  ava visualize --query \"<text>\" --data <json|@file|-> [options]\n\nReturns { chartType, config, html } as JSON, or null if no chart is recommended.\nWith --output, also writes HTML and includes its absolute path in output.\n\nOptions:\n  --query <text>         Required natural-language visualization request.\n  --data <json|@file|->  Required JSON array of objects, @file, or - for stdin.\n  -o, --output <path>    Save HTML to a new file; existing files are not overwritten.\n  -h, --help             Show help.\n\nEnvironment:\n  OPENAI_API_KEY        Required; read from the current environment.\n  OPENAI_MODEL          Model name (default: gpt-4o-mini).\n  OPENAI_BASE_URL       Optional API base URL.\n\nExample:\n  ava visualize --query \"Show revenue by region\" --data @rows.json -o chart.html";
