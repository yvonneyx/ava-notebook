import type { Options } from '../options';
export declare const description = "Analyze with natural language";
export declare const definition: {
    readonly positionals: 2;
    readonly options: {
        readonly strategy: {
            readonly type: "string";
        };
        readonly 'max-rows': {
            readonly type: "string";
        };
        readonly 'max-result-bytes': {
            readonly type: "string";
        };
    };
};
export declare function run([datasetId, query]: string[], options: Options): Promise<unknown>;
export declare const help = "Analyze with natural language.\n\nUsage:\n  ava analyze <dataset-id> \"<query>\" [options]\n\nUse the datasetId returned by ava source. Returns analysis as JSON.\nRequires OPENAI_API_KEY to have been set before loading that dataset.\n\nOptions:\n  --strategy <type>       direct or loop (default: direct).\n  --max-rows <n>          Maximum result rows, 1-10000 (default: 200).\n  --max-result-bytes <n>  Positive integer byte limit for result data\n                         (default: 1048576, or 1 MiB).\n  -h, --help              Show help.\n\nExample:\n  ava analyze ds_... \"What is the average revenue by region?\" --max-rows 100";
