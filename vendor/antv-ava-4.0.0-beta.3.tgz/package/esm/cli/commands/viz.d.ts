import type { Options } from '../options';
export declare const description = "Render a chart specification to HTML";
export declare const definition: {
    readonly positionals: 0;
    readonly options: {
        readonly spec: {
            readonly type: "string";
        };
        readonly output: {
            readonly type: "string";
            readonly short: "o";
        };
    };
};
export declare function run(_args: string[], options: Options): Promise<unknown>;
export declare const help = "Render a chart specification to HTML.\n\nUsage:\n  ava viz --spec <json|@file|-> --output <path>\n\nSpec must contain chartType and config (GPT-Vis JSON config), as returned by ava recommend.\nReturns { \"output\": \"<absolute-path>\" } as JSON. No API key is required.\n\nOptions:\n  --spec <json|@file|->  Required JSON spec, @file, or - for stdin.\n  -o, --output <path>    Required HTML file path; existing files are not overwritten.\n  -h, --help             Show help.\n\nExample:\n  ava viz --spec @chart.json --output chart.html";
