export declare const description = "Generate DSL without executing it";
export declare const definition: {
    readonly positionals: 2;
    readonly options: {};
};
export declare function run([datasetId, query]: string[]): Promise<unknown>;
export declare const help = "Generate DSL without executing it.\n\nUsage:\n  ava translate <dataset-id> \"<query>\"\n\nUse the datasetId returned by ava source.\nReturns { \"dsl\": \"...\" } as JSON; use ava query to execute the DSL.\nRequires OPENAI_API_KEY to have been set before loading that dataset.\n\nOptions:\n  -h, --help  Show help.\n\nExample:\n  ava translate ds_... \"What is the average revenue by region?\"";
