import type { Options } from '../options';
export declare const description = "Describe the dataset";
export declare const definition: {
    readonly positionals: 1;
    readonly options: {
        readonly file: {
            readonly type: "string";
        };
    };
};
export declare function run([datasetId]: string[], options: Options): Promise<unknown>;
export declare const help = "Describe the dataset.\n\nUsage:\n  ava schema <dataset-id> [--file <path>]\n\nReturns tables, fields, relations and language (name, fence, optional instructions)\nas JSON, without computing statistics. Use language to write queries for this session.\nUse the datasetId returned by ava source.\n\nOptions:\n  --file <path>  Set the schema from a JSON file instead of discovering it.\n                 Replaces the saved schema and clears the saved profile.\n  -h, --help     Show help.\n\nExample:\n  ava schema ds_...\n  ava schema ds_... --file schema.json";
