import type { Options } from '../options';
export declare const description = "Recommend a chart specification";
export declare const definition: {
    readonly positionals: 0;
    readonly options: {
        readonly query: {
            readonly type: "string";
        };
        readonly data: {
            readonly type: "string";
        };
    };
};
export declare function run(_args: string[], options: Options): Promise<unknown>;
export declare const help = "Recommend a chart specification.\n\nUsage:\n  ava recommend --query \"<text>\" --data <json|@file|->\n\nReturns { \"chartType\": \"...\", \"config\": {...} }, or null if no chart is recommended.\nA non-null result can be passed to ava viz --spec.\n\nOptions:\n  --query <text>         Required natural-language visualization request.\n  --data <json|@file|->  Required JSON array of objects, @file, or - for stdin.\n  -h, --help             Show help.\n\nEnvironment:\n  OPENAI_API_KEY        Required; read from the current environment.\n  OPENAI_MODEL          Model name (default: gpt-4o-mini).\n  OPENAI_BASE_URL       Optional API base URL.\n\nExample:\n  ava recommend --query \"Show revenue by region\" --data @rows.json";
