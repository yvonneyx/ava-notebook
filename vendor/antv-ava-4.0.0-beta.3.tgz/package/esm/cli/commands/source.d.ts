import type { Options } from '../options';
export declare const description = "Load a source and return a dataset ID";
export declare const definition: {
    readonly positionals: 1;
    readonly options: {
        readonly type: {
            readonly type: "string";
            readonly short: "t";
        };
        readonly engine: {
            readonly type: "string";
        };
    };
};
export declare function run([dataset]: string[], options: Options): Promise<{
    datasetId: string;
}>;
/**
 * Guide terminal users through the next steps with their newly loaded dataset.
 */
export declare function formatResult({ datasetId }: {
    datasetId: string;
}): string;
export declare const help = "Load a source and return a dataset ID.\n\nUsage:\n  ava source <dataset> [options]\n\nArguments:\n  dataset           File/URL, @file containing a source config, or - for stdin.\n                    Config format: { \"type\": \"json\", \"options\": { \"data\": [] } }\n                    Relative paths resolve from the current working directory.\n\nOptions:\n  -t, --type <type>  Override the type inferred from the file extension.\n                    Types: csv-file, json-file, parquet, excel, sqlite.\n                    Cannot be used with @file, stdin configs, or Feishu URLs.\n  --engine <type>    duckdb, python, javascript, supabase, or clickhouse.\n                    Default: supabase/clickhouse for those sources, otherwise duckdb.\n                    Fixed for the session; source support depends on the engine.\n                    feishu-bitable uses duckdb. The loaded view is named data.\n  -h, --help         Show help.\n\nFeishu Bitable:\n  A /base/ or /wiki/ link from feishu.cn or larksuite.com is detected automatically:\n    ava source \"https://my.feishu.cn/base/<appToken>?table=<tableId>\"\n    ava source \"https://my.feishu.cn/wiki/<nodeToken>?table=<tableId>\"\n  A wiki node is resolved to the Bitable it hosts, so the app also needs wiki\n  read access and membership of the wiki space.\n  Without ?table=, AVA uses the only table of the Bitable and lists the tables\n  when there are several. Or pass a \"feishu-bitable\" config via @file or stdin.\n  appId and appSecret are required. They are resolved from the config first,\n  then AVA_FEISHU_APP_ID / AVA_FEISHU_APP_SECRET, then ~/.ava/feishu.json;\n  in a terminal AVA offers to bind and save them.\n  The whole table is loaded as one view named data; the view query is ignored.\n  Docx and Sheets links are not supported.\n\nEnvironment:\n  OPENAI_API_KEY     Required for text sources and subsequent AI commands.\n  OPENAI_MODEL       Model name (default: gpt-4o-mini).\n  OPENAI_BASE_URL    Optional API base URL.\n  AVA_FEISHU_APP_ID      Feishu app credentials for feishu-bitable sources.\n  AVA_FEISHU_APP_SECRET\n  Model settings are fixed when the dataset is loaded.\n\nIn a terminal, shows the dataset ID and suggested next commands.\nWhen piped or redirected, returns JSON containing datasetId.\nIDs use a sanitized source name plus a random suffix.\nRequires Node.js 22.13+ on macOS or Linux.\nSessions expire after 30 idle minutes; dispose releases them immediately.\nPython requires python3 and pandas; local Python execution is not sandboxed.\nJavaScript accepts inline csv/json/text configs. Use ava schema to inspect the query language.\n\nExamples:\n  ava source sales.csv\n  ava source sales.csv --engine python\n  ava source @source.json\n  echo '{ \"type\": \"json\", \"options\": { \"data\": [{ \"sales\": 10 }] } }' | ava source -\n  ava source \"https://my.feishu.cn/base/<appToken>?table=<tableId>\"\n  ava source \"https://my.feishu.cn/wiki/<nodeToken>?table=<tableId>\"\n  ava source @feishu.json\n\nfeishu.json:\n{\n  \"type\": \"feishu-bitable\",\n  \"options\": {\n    \"url\": \"https://my.feishu.cn/base/<appToken>?table=<tableId>\",\n    \"appId\": \"<app-id>\",\n    \"appSecret\": \"<app-secret>\"\n  }\n}\n    Provide url or both appToken and tableId; they must name the same table.\n    Keep appSecret out of version control and logs.\n";
