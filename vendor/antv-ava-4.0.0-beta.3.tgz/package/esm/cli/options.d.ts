export type Options = Record<string, string | boolean | undefined>;
export type OptionDefinitions = Record<string, {
    type: 'string' | 'boolean';
    short?: string;
    multiple?: false;
}>;
export declare function parse(argv: string[], definitions?: OptionDefinitions): {
    values: string[];
    options: Options;
};
export declare function option(options: Options, name: string): string | undefined;
export declare function list(options: Options, name: string): string[] | undefined;
export declare function numberOption(options: Options, name: string, max?: number): number | undefined;
