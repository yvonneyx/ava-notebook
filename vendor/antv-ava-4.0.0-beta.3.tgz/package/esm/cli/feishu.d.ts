export declare function feishuBindError(code: unknown, msg: unknown): Error;
export declare function feishuCredentials(options: {
    appId?: string;
    appSecret?: string;
    url?: string;
}): Promise<{
    appId: string;
    appSecret: string;
}>;
export declare function feishuUrl(dataset: string): URL | undefined;
export declare function isFeishuHostUrl(dataset: string): boolean;
export declare function isFeishuBitableUrl(dataset: string): boolean;
