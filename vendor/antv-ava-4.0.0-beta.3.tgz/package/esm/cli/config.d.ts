import type { LLMConfig } from '../types';
export declare function llmConfig(required?: boolean): LLMConfig;
