#!/usr/bin/env node
type Write = (value: string) => void;
export declare function run(argv: string[], write?: Write): Promise<void>;
export {};
