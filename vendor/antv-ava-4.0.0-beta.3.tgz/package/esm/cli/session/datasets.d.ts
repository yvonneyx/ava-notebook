import { AVA } from '../../index';
import type { DataSourceConfig, EngineConfig, LLMConfig, Schema } from '../../types';
export declare function disposeDataset(): Promise<void>;
export declare function createDataset(source: DataSourceConfig, llm: LLMConfig, engine?: EngineConfig['type']): Promise<void>;
export declare function withDataset<T>(operation: (instance: AVA) => Promise<T>): Promise<T>;
export declare function describeDataset(schema?: Schema): Promise<{
    language: import("../../types").QueryLanguage;
    models: (Pick<import("../../types").Model, "name" | "primaryKey" | "uniqueKeys"> & {
        tableReference: Pick<import("../../types").TableReference, "catalog" | "schema" | "table">;
        columns: Pick<import("../../types").Column, "name" | "type" | "notNull">[];
    })[];
    relationships?: (Pick<import("../../types").Relationship, "name" | "models" | "condition"> & {
        joinType: Extract<import("../../types").JoinType, "ONE_TO_ONE" | "MANY_TO_ONE">;
    })[];
    views?: Pick<import("../../types").View, "name" | "statement">[];
}>;
