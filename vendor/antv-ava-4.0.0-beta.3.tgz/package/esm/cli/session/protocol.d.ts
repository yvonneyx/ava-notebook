import { z } from 'zod';
export declare const IPC_TIMEOUT_MS = 120000;
export declare const IPC_MAX_REQUEST_BYTES: number;
export declare const IPC_MAX_RESPONSE_BYTES: number;
export declare const sourceConfig: z.ZodEffects<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
    type: z.ZodLiteral<"csv-file">;
    options: z.ZodObject<{
        path: z.ZodString;
        headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    } & {
        options: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    }, "strict", z.ZodTypeAny, {
        path?: string;
        options?: Record<string, unknown>;
        headers?: Record<string, string>;
    }, {
        path?: string;
        options?: Record<string, unknown>;
        headers?: Record<string, string>;
    }>;
}, "strict", z.ZodTypeAny, {
    options?: {
        path?: string;
        options?: Record<string, unknown>;
        headers?: Record<string, string>;
    };
    type?: "csv-file";
}, {
    options?: {
        path?: string;
        options?: Record<string, unknown>;
        headers?: Record<string, string>;
    };
    type?: "csv-file";
}>, z.ZodObject<{
    type: z.ZodLiteral<"json-file">;
    options: z.ZodObject<{
        path: z.ZodString;
        headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    } & {
        options: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    }, "strict", z.ZodTypeAny, {
        path?: string;
        options?: Record<string, unknown>;
        headers?: Record<string, string>;
    }, {
        path?: string;
        options?: Record<string, unknown>;
        headers?: Record<string, string>;
    }>;
}, "strict", z.ZodTypeAny, {
    options?: {
        path?: string;
        options?: Record<string, unknown>;
        headers?: Record<string, string>;
    };
    type?: "json-file";
}, {
    options?: {
        path?: string;
        options?: Record<string, unknown>;
        headers?: Record<string, string>;
    };
    type?: "json-file";
}>, z.ZodObject<{
    type: z.ZodLiteral<"parquet">;
    options: z.ZodObject<{
        path: z.ZodString;
        headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, "strict", z.ZodTypeAny, {
        path?: string;
        headers?: Record<string, string>;
    }, {
        path?: string;
        headers?: Record<string, string>;
    }>;
}, "strict", z.ZodTypeAny, {
    options?: {
        path?: string;
        headers?: Record<string, string>;
    };
    type?: "parquet";
}, {
    options?: {
        path?: string;
        headers?: Record<string, string>;
    };
    type?: "parquet";
}>, z.ZodObject<{
    type: z.ZodLiteral<"excel">;
    options: z.ZodObject<{
        path: z.ZodString;
        headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        sheets: z.ZodOptional<z.ZodEffects<z.ZodArray<z.ZodObject<{
            sheet: z.ZodString;
            range: z.ZodOptional<z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, string, string>>;
            header: z.ZodDefault<z.ZodBoolean>;
            all_varchar: z.ZodOptional<z.ZodBoolean>;
            ignore_errors: z.ZodOptional<z.ZodBoolean>;
            stop_at_empty: z.ZodOptional<z.ZodBoolean>;
            empty_as_varchar: z.ZodOptional<z.ZodBoolean>;
        }, "strict", z.ZodTypeAny, {
            header?: boolean;
            all_varchar?: boolean;
            ignore_errors?: boolean;
            sheet?: string;
            range?: string;
            stop_at_empty?: boolean;
            empty_as_varchar?: boolean;
        }, {
            header?: boolean;
            all_varchar?: boolean;
            ignore_errors?: boolean;
            sheet?: string;
            range?: string;
            stop_at_empty?: boolean;
            empty_as_varchar?: boolean;
        }>, "atleastone">, [{
            header?: boolean;
            all_varchar?: boolean;
            ignore_errors?: boolean;
            sheet?: string;
            range?: string;
            stop_at_empty?: boolean;
            empty_as_varchar?: boolean;
        }, ...{
            header?: boolean;
            all_varchar?: boolean;
            ignore_errors?: boolean;
            sheet?: string;
            range?: string;
            stop_at_empty?: boolean;
            empty_as_varchar?: boolean;
        }[]], [{
            header?: boolean;
            all_varchar?: boolean;
            ignore_errors?: boolean;
            sheet?: string;
            range?: string;
            stop_at_empty?: boolean;
            empty_as_varchar?: boolean;
        }, ...{
            header?: boolean;
            all_varchar?: boolean;
            ignore_errors?: boolean;
            sheet?: string;
            range?: string;
            stop_at_empty?: boolean;
            empty_as_varchar?: boolean;
        }[]]>>;
    }, "strict", z.ZodTypeAny, {
        path?: string;
        headers?: Record<string, string>;
        sheets?: [{
            header?: boolean;
            all_varchar?: boolean;
            ignore_errors?: boolean;
            sheet?: string;
            range?: string;
            stop_at_empty?: boolean;
            empty_as_varchar?: boolean;
        }, ...{
            header?: boolean;
            all_varchar?: boolean;
            ignore_errors?: boolean;
            sheet?: string;
            range?: string;
            stop_at_empty?: boolean;
            empty_as_varchar?: boolean;
        }[]];
    }, {
        path?: string;
        headers?: Record<string, string>;
        sheets?: [{
            header?: boolean;
            all_varchar?: boolean;
            ignore_errors?: boolean;
            sheet?: string;
            range?: string;
            stop_at_empty?: boolean;
            empty_as_varchar?: boolean;
        }, ...{
            header?: boolean;
            all_varchar?: boolean;
            ignore_errors?: boolean;
            sheet?: string;
            range?: string;
            stop_at_empty?: boolean;
            empty_as_varchar?: boolean;
        }[]];
    }>;
}, "strict", z.ZodTypeAny, {
    options?: {
        path?: string;
        headers?: Record<string, string>;
        sheets?: [{
            header?: boolean;
            all_varchar?: boolean;
            ignore_errors?: boolean;
            sheet?: string;
            range?: string;
            stop_at_empty?: boolean;
            empty_as_varchar?: boolean;
        }, ...{
            header?: boolean;
            all_varchar?: boolean;
            ignore_errors?: boolean;
            sheet?: string;
            range?: string;
            stop_at_empty?: boolean;
            empty_as_varchar?: boolean;
        }[]];
    };
    type?: "excel";
}, {
    options?: {
        path?: string;
        headers?: Record<string, string>;
        sheets?: [{
            header?: boolean;
            all_varchar?: boolean;
            ignore_errors?: boolean;
            sheet?: string;
            range?: string;
            stop_at_empty?: boolean;
            empty_as_varchar?: boolean;
        }, ...{
            header?: boolean;
            all_varchar?: boolean;
            ignore_errors?: boolean;
            sheet?: string;
            range?: string;
            stop_at_empty?: boolean;
            empty_as_varchar?: boolean;
        }[]];
    };
    type?: "excel";
}>, z.ZodObject<{
    type: z.ZodLiteral<"sqlite">;
    options: z.ZodObject<{
        path: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        path?: string;
    }, {
        path?: string;
    }>;
}, "strict", z.ZodTypeAny, {
    options?: {
        path?: string;
    };
    type?: "sqlite";
}, {
    options?: {
        path?: string;
    };
    type?: "sqlite";
}>, z.ZodObject<{
    type: z.ZodLiteral<"csv">;
    options: z.ZodObject<{
        csv: z.ZodString;
        options: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    }, "strict", z.ZodTypeAny, {
        csv?: string;
        options?: Record<string, unknown>;
    }, {
        csv?: string;
        options?: Record<string, unknown>;
    }>;
}, "strict", z.ZodTypeAny, {
    options?: {
        csv?: string;
        options?: Record<string, unknown>;
    };
    type?: "csv";
}, {
    options?: {
        csv?: string;
        options?: Record<string, unknown>;
    };
    type?: "csv";
}>, z.ZodObject<{
    type: z.ZodLiteral<"json">;
    options: z.ZodObject<{
        data: z.ZodArray<z.ZodRecord<z.ZodString, z.ZodUnknown>, "many">;
        options: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    }, "strict", z.ZodTypeAny, {
        options?: Record<string, unknown>;
        data?: Record<string, unknown>[];
    }, {
        options?: Record<string, unknown>;
        data?: Record<string, unknown>[];
    }>;
}, "strict", z.ZodTypeAny, {
    options?: {
        options?: Record<string, unknown>;
        data?: Record<string, unknown>[];
    };
    type?: "json";
}, {
    options?: {
        options?: Record<string, unknown>;
        data?: Record<string, unknown>[];
    };
    type?: "json";
}>, z.ZodObject<{
    type: z.ZodLiteral<"text">;
    options: z.ZodObject<{
        text: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        text?: string;
    }, {
        text?: string;
    }>;
}, "strict", z.ZodTypeAny, {
    options?: {
        text?: string;
    };
    type?: "text";
}, {
    options?: {
        text?: string;
    };
    type?: "text";
}>, z.ZodObject<{
    type: z.ZodLiteral<"mysql">;
    options: z.ZodObject<{
        host: z.ZodString;
        database: z.ZodString;
        port: z.ZodOptional<z.ZodNumber>;
        user: z.ZodOptional<z.ZodString>;
        password: z.ZodOptional<z.ZodString>;
        ssh: z.ZodOptional<z.ZodObject<{
            host: z.ZodString;
            user: z.ZodString;
            port: z.ZodOptional<z.ZodNumber>;
            password: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            host?: string;
            password?: string;
            port?: number;
            user?: string;
        }, {
            host?: string;
            password?: string;
            port?: number;
            user?: string;
        }>>;
    }, "strict", z.ZodTypeAny, {
        host?: string;
        database?: string;
        password?: string;
        port?: number;
        user?: string;
        ssh?: {
            host?: string;
            password?: string;
            port?: number;
            user?: string;
        };
    }, {
        host?: string;
        database?: string;
        password?: string;
        port?: number;
        user?: string;
        ssh?: {
            host?: string;
            password?: string;
            port?: number;
            user?: string;
        };
    }>;
}, "strict", z.ZodTypeAny, {
    options?: {
        host?: string;
        database?: string;
        password?: string;
        port?: number;
        user?: string;
        ssh?: {
            host?: string;
            password?: string;
            port?: number;
            user?: string;
        };
    };
    type?: "mysql";
}, {
    options?: {
        host?: string;
        database?: string;
        password?: string;
        port?: number;
        user?: string;
        ssh?: {
            host?: string;
            password?: string;
            port?: number;
            user?: string;
        };
    };
    type?: "mysql";
}>, z.ZodObject<{
    type: z.ZodLiteral<"mongodb">;
    options: z.ZodObject<{
        connection: z.ZodOptional<z.ZodString>;
        host: z.ZodOptional<z.ZodString>;
        database: z.ZodString;
        port: z.ZodOptional<z.ZodNumber>;
        user: z.ZodOptional<z.ZodString>;
        password: z.ZodOptional<z.ZodString>;
        authSource: z.ZodOptional<z.ZodString>;
        srv: z.ZodOptional<z.ZodBoolean>;
        tls: z.ZodOptional<z.ZodBoolean>;
        ssl: z.ZodOptional<z.ZodBoolean>;
        tlsCAFile: z.ZodOptional<z.ZodString>;
        tlsAllowInvalidCertificates: z.ZodOptional<z.ZodBoolean>;
    }, "strict", z.ZodTypeAny, {
        host?: string;
        database?: string;
        password?: string;
        tls?: boolean;
        connection?: string;
        port?: number;
        user?: string;
        srv?: boolean;
        authSource?: string;
        ssl?: boolean;
        tlsCAFile?: string;
        tlsAllowInvalidCertificates?: boolean;
    }, {
        host?: string;
        database?: string;
        password?: string;
        tls?: boolean;
        connection?: string;
        port?: number;
        user?: string;
        srv?: boolean;
        authSource?: string;
        ssl?: boolean;
        tlsCAFile?: string;
        tlsAllowInvalidCertificates?: boolean;
    }>;
}, "strict", z.ZodTypeAny, {
    options?: {
        host?: string;
        database?: string;
        password?: string;
        tls?: boolean;
        connection?: string;
        port?: number;
        user?: string;
        srv?: boolean;
        authSource?: string;
        ssl?: boolean;
        tlsCAFile?: string;
        tlsAllowInvalidCertificates?: boolean;
    };
    type?: "mongodb";
}, {
    options?: {
        host?: string;
        database?: string;
        password?: string;
        tls?: boolean;
        connection?: string;
        port?: number;
        user?: string;
        srv?: boolean;
        authSource?: string;
        ssl?: boolean;
        tlsCAFile?: string;
        tlsAllowInvalidCertificates?: boolean;
    };
    type?: "mongodb";
}>, z.ZodObject<{
    type: z.ZodLiteral<"postgresql">;
    options: z.ZodObject<{
        host: z.ZodString;
        database: z.ZodString;
        port: z.ZodOptional<z.ZodNumber>;
        user: z.ZodOptional<z.ZodString>;
        password: z.ZodOptional<z.ZodString>;
        ssh: z.ZodOptional<z.ZodObject<{
            host: z.ZodString;
            user: z.ZodString;
            port: z.ZodOptional<z.ZodNumber>;
            password: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            host?: string;
            password?: string;
            port?: number;
            user?: string;
        }, {
            host?: string;
            password?: string;
            port?: number;
            user?: string;
        }>>;
    } & {
        schema: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        schema?: string;
        host?: string;
        database?: string;
        password?: string;
        port?: number;
        user?: string;
        ssh?: {
            host?: string;
            password?: string;
            port?: number;
            user?: string;
        };
    }, {
        schema?: string;
        host?: string;
        database?: string;
        password?: string;
        port?: number;
        user?: string;
        ssh?: {
            host?: string;
            password?: string;
            port?: number;
            user?: string;
        };
    }>;
}, "strict", z.ZodTypeAny, {
    options?: {
        schema?: string;
        host?: string;
        database?: string;
        password?: string;
        port?: number;
        user?: string;
        ssh?: {
            host?: string;
            password?: string;
            port?: number;
            user?: string;
        };
    };
    type?: "postgresql";
}, {
    options?: {
        schema?: string;
        host?: string;
        database?: string;
        password?: string;
        port?: number;
        user?: string;
        ssh?: {
            host?: string;
            password?: string;
            port?: number;
            user?: string;
        };
    };
    type?: "postgresql";
}>, z.ZodObject<{
    type: z.ZodLiteral<"supabase">;
    options: z.ZodObject<{
        accessToken: z.ZodString;
        projectRef: z.ZodString;
    }, "strict", z.ZodTypeAny, {
        accessToken?: string;
        projectRef?: string;
    }, {
        accessToken?: string;
        projectRef?: string;
    }>;
}, "strict", z.ZodTypeAny, {
    options?: {
        accessToken?: string;
        projectRef?: string;
    };
    type?: "supabase";
}, {
    options?: {
        accessToken?: string;
        projectRef?: string;
    };
    type?: "supabase";
}>, z.ZodObject<{
    type: z.ZodLiteral<"clickhouse">;
    options: z.ZodEffects<z.ZodObject<{
        host: z.ZodOptional<z.ZodString>;
        url: z.ZodOptional<z.ZodString>;
        database: z.ZodString;
        port: z.ZodOptional<z.ZodNumber>;
        user: z.ZodOptional<z.ZodString>;
        username: z.ZodOptional<z.ZodString>;
        password: z.ZodOptional<z.ZodString>;
        access_token: z.ZodOptional<z.ZodString>;
        pathname: z.ZodOptional<z.ZodString>;
        application: z.ZodOptional<z.ZodString>;
        session_id: z.ZodOptional<z.ZodString>;
        role: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>>;
        http_headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        request_timeout: z.ZodOptional<z.ZodNumber>;
    }, "passthrough", z.ZodTypeAny, z.objectOutputType<{
        host: z.ZodOptional<z.ZodString>;
        url: z.ZodOptional<z.ZodString>;
        database: z.ZodString;
        port: z.ZodOptional<z.ZodNumber>;
        user: z.ZodOptional<z.ZodString>;
        username: z.ZodOptional<z.ZodString>;
        password: z.ZodOptional<z.ZodString>;
        access_token: z.ZodOptional<z.ZodString>;
        pathname: z.ZodOptional<z.ZodString>;
        application: z.ZodOptional<z.ZodString>;
        session_id: z.ZodOptional<z.ZodString>;
        role: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>>;
        http_headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        request_timeout: z.ZodOptional<z.ZodNumber>;
    }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
        host: z.ZodOptional<z.ZodString>;
        url: z.ZodOptional<z.ZodString>;
        database: z.ZodString;
        port: z.ZodOptional<z.ZodNumber>;
        user: z.ZodOptional<z.ZodString>;
        username: z.ZodOptional<z.ZodString>;
        password: z.ZodOptional<z.ZodString>;
        access_token: z.ZodOptional<z.ZodString>;
        pathname: z.ZodOptional<z.ZodString>;
        application: z.ZodOptional<z.ZodString>;
        session_id: z.ZodOptional<z.ZodString>;
        role: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>>;
        http_headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        request_timeout: z.ZodOptional<z.ZodNumber>;
    }, z.ZodTypeAny, "passthrough">>, z.objectOutputType<{
        host: z.ZodOptional<z.ZodString>;
        url: z.ZodOptional<z.ZodString>;
        database: z.ZodString;
        port: z.ZodOptional<z.ZodNumber>;
        user: z.ZodOptional<z.ZodString>;
        username: z.ZodOptional<z.ZodString>;
        password: z.ZodOptional<z.ZodString>;
        access_token: z.ZodOptional<z.ZodString>;
        pathname: z.ZodOptional<z.ZodString>;
        application: z.ZodOptional<z.ZodString>;
        session_id: z.ZodOptional<z.ZodString>;
        role: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>>;
        http_headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        request_timeout: z.ZodOptional<z.ZodNumber>;
    }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
        host: z.ZodOptional<z.ZodString>;
        url: z.ZodOptional<z.ZodString>;
        database: z.ZodString;
        port: z.ZodOptional<z.ZodNumber>;
        user: z.ZodOptional<z.ZodString>;
        username: z.ZodOptional<z.ZodString>;
        password: z.ZodOptional<z.ZodString>;
        access_token: z.ZodOptional<z.ZodString>;
        pathname: z.ZodOptional<z.ZodString>;
        application: z.ZodOptional<z.ZodString>;
        session_id: z.ZodOptional<z.ZodString>;
        role: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>>;
        http_headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        request_timeout: z.ZodOptional<z.ZodNumber>;
    }, z.ZodTypeAny, "passthrough">>;
}, "strict", z.ZodTypeAny, {
    options?: {
        host?: string;
        url?: string;
        username?: string;
        database?: string;
        pathname?: string;
        request_timeout?: number;
        password?: string;
        access_token?: string;
        application?: string;
        session_id?: string;
        role?: string | string[];
        http_headers?: Record<string, string>;
        port?: number;
        user?: string;
    } & {
        [k: string]: unknown;
    };
    type?: "clickhouse";
}, {
    options?: {
        host?: string;
        url?: string;
        username?: string;
        database?: string;
        pathname?: string;
        request_timeout?: number;
        password?: string;
        access_token?: string;
        application?: string;
        session_id?: string;
        role?: string | string[];
        http_headers?: Record<string, string>;
        port?: number;
        user?: string;
    } & {
        [k: string]: unknown;
    };
    type?: "clickhouse";
}>, z.ZodObject<{
    type: z.ZodLiteral<"feishu-bitable">;
    options: z.ZodEffects<z.ZodObject<{
        url: z.ZodOptional<z.ZodString>;
        appToken: z.ZodOptional<z.ZodString>;
        tableId: z.ZodOptional<z.ZodString>;
        appSecret: z.ZodOptional<z.ZodString>;
        appId: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        url?: string;
        tableId?: string;
        appToken?: string;
        appSecret?: string;
        appId?: string;
    }, {
        url?: string;
        tableId?: string;
        appToken?: string;
        appSecret?: string;
        appId?: string;
    }>, {
        url?: string;
        tableId?: string;
        appToken?: string;
        appSecret?: string;
        appId?: string;
    }, {
        url?: string;
        tableId?: string;
        appToken?: string;
        appSecret?: string;
        appId?: string;
    }>;
}, "strict", z.ZodTypeAny, {
    options?: {
        url?: string;
        tableId?: string;
        appToken?: string;
        appSecret?: string;
        appId?: string;
    };
    type?: "feishu-bitable";
}, {
    options?: {
        url?: string;
        tableId?: string;
        appToken?: string;
        appSecret?: string;
        appId?: string;
    };
    type?: "feishu-bitable";
}>]>, {
    type: "csv";
    options: import("../../types").CSVSourceOptions;
} | {
    type: "json";
    options: import("../../types").JsonSourceOptions;
} | {
    type: "text";
    options: import("../../types").TextSourceOptions;
} | {
    type: "csv-file";
    options: import("../../types").CSVFileSourceOptions;
} | {
    type: "json-file";
    options: import("../../types").JsonFileSourceOptions;
} | {
    type: "parquet";
    options: import("../../types").ParquetSourceOptions;
} | {
    type: "excel";
    options: import("../../types").ExcelSourceOptions;
} | {
    type: "mysql";
    options: import("../../types").MySQLSourceOptions;
} | {
    type: "postgresql";
    options: import("../../types").PostgreSQLSourceOptions;
} | {
    type: "sqlite";
    options: import("../../types").SQLiteSourceOptions;
} | {
    type: "mongodb";
    options: import("../../types").MongoDBSourceOptions;
} | {
    type: "supabase";
    options: import("../../types").SupabaseSourceOptions;
} | {
    type: "clickhouse";
    options: import("../../types").ClickHouseSourceOptions;
} | {
    type: "feishu-bitable";
    options: import("../../types").FeishuBitableSourceOptions;
}, {
    options?: {
        path?: string;
        options?: Record<string, unknown>;
        headers?: Record<string, string>;
    };
    type?: "csv-file";
} | {
    options?: {
        path?: string;
        options?: Record<string, unknown>;
        headers?: Record<string, string>;
    };
    type?: "json-file";
} | {
    options?: {
        path?: string;
        headers?: Record<string, string>;
    };
    type?: "parquet";
} | {
    options?: {
        path?: string;
        headers?: Record<string, string>;
        sheets?: [{
            header?: boolean;
            all_varchar?: boolean;
            ignore_errors?: boolean;
            sheet?: string;
            range?: string;
            stop_at_empty?: boolean;
            empty_as_varchar?: boolean;
        }, ...{
            header?: boolean;
            all_varchar?: boolean;
            ignore_errors?: boolean;
            sheet?: string;
            range?: string;
            stop_at_empty?: boolean;
            empty_as_varchar?: boolean;
        }[]];
    };
    type?: "excel";
} | {
    options?: {
        path?: string;
    };
    type?: "sqlite";
} | {
    options?: {
        csv?: string;
        options?: Record<string, unknown>;
    };
    type?: "csv";
} | {
    options?: {
        options?: Record<string, unknown>;
        data?: Record<string, unknown>[];
    };
    type?: "json";
} | {
    options?: {
        text?: string;
    };
    type?: "text";
} | {
    options?: {
        host?: string;
        database?: string;
        password?: string;
        port?: number;
        user?: string;
        ssh?: {
            host?: string;
            password?: string;
            port?: number;
            user?: string;
        };
    };
    type?: "mysql";
} | {
    options?: {
        host?: string;
        database?: string;
        password?: string;
        tls?: boolean;
        connection?: string;
        port?: number;
        user?: string;
        srv?: boolean;
        authSource?: string;
        ssl?: boolean;
        tlsCAFile?: string;
        tlsAllowInvalidCertificates?: boolean;
    };
    type?: "mongodb";
} | {
    options?: {
        schema?: string;
        host?: string;
        database?: string;
        password?: string;
        port?: number;
        user?: string;
        ssh?: {
            host?: string;
            password?: string;
            port?: number;
            user?: string;
        };
    };
    type?: "postgresql";
} | {
    options?: {
        accessToken?: string;
        projectRef?: string;
    };
    type?: "supabase";
} | {
    options?: {
        host?: string;
        url?: string;
        username?: string;
        database?: string;
        pathname?: string;
        request_timeout?: number;
        password?: string;
        access_token?: string;
        application?: string;
        session_id?: string;
        role?: string | string[];
        http_headers?: Record<string, string>;
        port?: number;
        user?: string;
    } & {
        [k: string]: unknown;
    };
    type?: "clickhouse";
} | {
    options?: {
        url?: string;
        tableId?: string;
        appToken?: string;
        appSecret?: string;
        appId?: string;
    };
    type?: "feishu-bitable";
}>;
export declare const modelSchema: z.ZodObject<{
    model: z.ZodString;
    apiKey: z.ZodOptional<z.ZodString>;
    baseURL: z.ZodOptional<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    model?: string;
    apiKey?: string;
    baseURL?: string;
}, {
    model?: string;
    apiKey?: string;
    baseURL?: string;
}>;
export declare const engineTypeSchema: z.ZodEnum<["duckdb", "python", "javascript", "supabase", "clickhouse"]>;
export declare const requestSchema: z.ZodDiscriminatedUnion<"command", [z.ZodObject<{
    command: z.ZodLiteral<"schema">;
    schema: z.ZodOptional<z.ZodType<import("../../types").Schema, z.ZodTypeDef, import("../../types").Schema>>;
}, "strict", z.ZodTypeAny, {
    schema?: import("../../types").Schema;
    command?: "schema";
}, {
    schema?: import("../../types").Schema;
    command?: "schema";
}>, z.ZodObject<{
    command: z.ZodLiteral<"profile">;
    metrics: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    profile: z.ZodOptional<z.ZodType<import("../../types").Profile, z.ZodTypeDef, import("../../types").Profile>>;
}, "strict", z.ZodTypeAny, {
    metrics?: string[];
    profile?: import("../../types").Profile;
    command?: "profile";
}, {
    metrics?: string[];
    profile?: import("../../types").Profile;
    command?: "profile";
}>, z.ZodObject<{
    command: z.ZodLiteral<"suggest">;
    count: z.ZodNumber;
}, "strict", z.ZodTypeAny, {
    count?: number;
    command?: "suggest";
}, {
    count?: number;
    command?: "suggest";
}>, z.ZodObject<{
    maxRows: z.ZodOptional<z.ZodNumber>;
    maxResultBytes: z.ZodOptional<z.ZodNumber>;
    command: z.ZodLiteral<"analyze">;
    query: z.ZodString;
    strategy: z.ZodOptional<z.ZodEnum<["direct", "loop"]>>;
}, "strict", z.ZodTypeAny, {
    maxRows?: number;
    maxResultBytes?: number;
    strategy?: "direct" | "loop";
    query?: string;
    command?: "analyze";
}, {
    maxRows?: number;
    maxResultBytes?: number;
    strategy?: "direct" | "loop";
    query?: string;
    command?: "analyze";
}>, z.ZodObject<{
    command: z.ZodLiteral<"translate">;
    query: z.ZodString;
}, "strict", z.ZodTypeAny, {
    query?: string;
    command?: "translate";
}, {
    query?: string;
    command?: "translate";
}>, z.ZodObject<{
    maxRows: z.ZodOptional<z.ZodNumber>;
    maxResultBytes: z.ZodOptional<z.ZodNumber>;
    command: z.ZodLiteral<"query">;
    dsl: z.ZodString;
}, "strict", z.ZodTypeAny, {
    maxRows?: number;
    maxResultBytes?: number;
    dsl?: string;
    command?: "query";
}, {
    maxRows?: number;
    maxResultBytes?: number;
    dsl?: string;
    command?: "query";
}>, z.ZodObject<{
    command: z.ZodLiteral<"dispose">;
}, "strict", z.ZodTypeAny, {
    command?: "dispose";
}, {
    command?: "dispose";
}>]>;
export type Request = z.infer<typeof requestSchema>;
export declare const startupSchema: z.ZodObject<{
    source: z.ZodEffects<z.ZodDiscriminatedUnion<"type", [z.ZodObject<{
        type: z.ZodLiteral<"csv-file">;
        options: z.ZodObject<{
            path: z.ZodString;
            headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        } & {
            options: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        }, "strict", z.ZodTypeAny, {
            path?: string;
            options?: Record<string, unknown>;
            headers?: Record<string, string>;
        }, {
            path?: string;
            options?: Record<string, unknown>;
            headers?: Record<string, string>;
        }>;
    }, "strict", z.ZodTypeAny, {
        options?: {
            path?: string;
            options?: Record<string, unknown>;
            headers?: Record<string, string>;
        };
        type?: "csv-file";
    }, {
        options?: {
            path?: string;
            options?: Record<string, unknown>;
            headers?: Record<string, string>;
        };
        type?: "csv-file";
    }>, z.ZodObject<{
        type: z.ZodLiteral<"json-file">;
        options: z.ZodObject<{
            path: z.ZodString;
            headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        } & {
            options: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        }, "strict", z.ZodTypeAny, {
            path?: string;
            options?: Record<string, unknown>;
            headers?: Record<string, string>;
        }, {
            path?: string;
            options?: Record<string, unknown>;
            headers?: Record<string, string>;
        }>;
    }, "strict", z.ZodTypeAny, {
        options?: {
            path?: string;
            options?: Record<string, unknown>;
            headers?: Record<string, string>;
        };
        type?: "json-file";
    }, {
        options?: {
            path?: string;
            options?: Record<string, unknown>;
            headers?: Record<string, string>;
        };
        type?: "json-file";
    }>, z.ZodObject<{
        type: z.ZodLiteral<"parquet">;
        options: z.ZodObject<{
            path: z.ZodString;
            headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        }, "strict", z.ZodTypeAny, {
            path?: string;
            headers?: Record<string, string>;
        }, {
            path?: string;
            headers?: Record<string, string>;
        }>;
    }, "strict", z.ZodTypeAny, {
        options?: {
            path?: string;
            headers?: Record<string, string>;
        };
        type?: "parquet";
    }, {
        options?: {
            path?: string;
            headers?: Record<string, string>;
        };
        type?: "parquet";
    }>, z.ZodObject<{
        type: z.ZodLiteral<"excel">;
        options: z.ZodObject<{
            path: z.ZodString;
            headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
            sheets: z.ZodOptional<z.ZodEffects<z.ZodArray<z.ZodObject<{
                sheet: z.ZodString;
                range: z.ZodOptional<z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, string, string>>;
                header: z.ZodDefault<z.ZodBoolean>;
                all_varchar: z.ZodOptional<z.ZodBoolean>;
                ignore_errors: z.ZodOptional<z.ZodBoolean>;
                stop_at_empty: z.ZodOptional<z.ZodBoolean>;
                empty_as_varchar: z.ZodOptional<z.ZodBoolean>;
            }, "strict", z.ZodTypeAny, {
                header?: boolean;
                all_varchar?: boolean;
                ignore_errors?: boolean;
                sheet?: string;
                range?: string;
                stop_at_empty?: boolean;
                empty_as_varchar?: boolean;
            }, {
                header?: boolean;
                all_varchar?: boolean;
                ignore_errors?: boolean;
                sheet?: string;
                range?: string;
                stop_at_empty?: boolean;
                empty_as_varchar?: boolean;
            }>, "atleastone">, [{
                header?: boolean;
                all_varchar?: boolean;
                ignore_errors?: boolean;
                sheet?: string;
                range?: string;
                stop_at_empty?: boolean;
                empty_as_varchar?: boolean;
            }, ...{
                header?: boolean;
                all_varchar?: boolean;
                ignore_errors?: boolean;
                sheet?: string;
                range?: string;
                stop_at_empty?: boolean;
                empty_as_varchar?: boolean;
            }[]], [{
                header?: boolean;
                all_varchar?: boolean;
                ignore_errors?: boolean;
                sheet?: string;
                range?: string;
                stop_at_empty?: boolean;
                empty_as_varchar?: boolean;
            }, ...{
                header?: boolean;
                all_varchar?: boolean;
                ignore_errors?: boolean;
                sheet?: string;
                range?: string;
                stop_at_empty?: boolean;
                empty_as_varchar?: boolean;
            }[]]>>;
        }, "strict", z.ZodTypeAny, {
            path?: string;
            headers?: Record<string, string>;
            sheets?: [{
                header?: boolean;
                all_varchar?: boolean;
                ignore_errors?: boolean;
                sheet?: string;
                range?: string;
                stop_at_empty?: boolean;
                empty_as_varchar?: boolean;
            }, ...{
                header?: boolean;
                all_varchar?: boolean;
                ignore_errors?: boolean;
                sheet?: string;
                range?: string;
                stop_at_empty?: boolean;
                empty_as_varchar?: boolean;
            }[]];
        }, {
            path?: string;
            headers?: Record<string, string>;
            sheets?: [{
                header?: boolean;
                all_varchar?: boolean;
                ignore_errors?: boolean;
                sheet?: string;
                range?: string;
                stop_at_empty?: boolean;
                empty_as_varchar?: boolean;
            }, ...{
                header?: boolean;
                all_varchar?: boolean;
                ignore_errors?: boolean;
                sheet?: string;
                range?: string;
                stop_at_empty?: boolean;
                empty_as_varchar?: boolean;
            }[]];
        }>;
    }, "strict", z.ZodTypeAny, {
        options?: {
            path?: string;
            headers?: Record<string, string>;
            sheets?: [{
                header?: boolean;
                all_varchar?: boolean;
                ignore_errors?: boolean;
                sheet?: string;
                range?: string;
                stop_at_empty?: boolean;
                empty_as_varchar?: boolean;
            }, ...{
                header?: boolean;
                all_varchar?: boolean;
                ignore_errors?: boolean;
                sheet?: string;
                range?: string;
                stop_at_empty?: boolean;
                empty_as_varchar?: boolean;
            }[]];
        };
        type?: "excel";
    }, {
        options?: {
            path?: string;
            headers?: Record<string, string>;
            sheets?: [{
                header?: boolean;
                all_varchar?: boolean;
                ignore_errors?: boolean;
                sheet?: string;
                range?: string;
                stop_at_empty?: boolean;
                empty_as_varchar?: boolean;
            }, ...{
                header?: boolean;
                all_varchar?: boolean;
                ignore_errors?: boolean;
                sheet?: string;
                range?: string;
                stop_at_empty?: boolean;
                empty_as_varchar?: boolean;
            }[]];
        };
        type?: "excel";
    }>, z.ZodObject<{
        type: z.ZodLiteral<"sqlite">;
        options: z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path?: string;
        }, {
            path?: string;
        }>;
    }, "strict", z.ZodTypeAny, {
        options?: {
            path?: string;
        };
        type?: "sqlite";
    }, {
        options?: {
            path?: string;
        };
        type?: "sqlite";
    }>, z.ZodObject<{
        type: z.ZodLiteral<"csv">;
        options: z.ZodObject<{
            csv: z.ZodString;
            options: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        }, "strict", z.ZodTypeAny, {
            csv?: string;
            options?: Record<string, unknown>;
        }, {
            csv?: string;
            options?: Record<string, unknown>;
        }>;
    }, "strict", z.ZodTypeAny, {
        options?: {
            csv?: string;
            options?: Record<string, unknown>;
        };
        type?: "csv";
    }, {
        options?: {
            csv?: string;
            options?: Record<string, unknown>;
        };
        type?: "csv";
    }>, z.ZodObject<{
        type: z.ZodLiteral<"json">;
        options: z.ZodObject<{
            data: z.ZodArray<z.ZodRecord<z.ZodString, z.ZodUnknown>, "many">;
            options: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        }, "strict", z.ZodTypeAny, {
            options?: Record<string, unknown>;
            data?: Record<string, unknown>[];
        }, {
            options?: Record<string, unknown>;
            data?: Record<string, unknown>[];
        }>;
    }, "strict", z.ZodTypeAny, {
        options?: {
            options?: Record<string, unknown>;
            data?: Record<string, unknown>[];
        };
        type?: "json";
    }, {
        options?: {
            options?: Record<string, unknown>;
            data?: Record<string, unknown>[];
        };
        type?: "json";
    }>, z.ZodObject<{
        type: z.ZodLiteral<"text">;
        options: z.ZodObject<{
            text: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            text?: string;
        }, {
            text?: string;
        }>;
    }, "strict", z.ZodTypeAny, {
        options?: {
            text?: string;
        };
        type?: "text";
    }, {
        options?: {
            text?: string;
        };
        type?: "text";
    }>, z.ZodObject<{
        type: z.ZodLiteral<"mysql">;
        options: z.ZodObject<{
            host: z.ZodString;
            database: z.ZodString;
            port: z.ZodOptional<z.ZodNumber>;
            user: z.ZodOptional<z.ZodString>;
            password: z.ZodOptional<z.ZodString>;
            ssh: z.ZodOptional<z.ZodObject<{
                host: z.ZodString;
                user: z.ZodString;
                port: z.ZodOptional<z.ZodNumber>;
                password: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                host?: string;
                password?: string;
                port?: number;
                user?: string;
            }, {
                host?: string;
                password?: string;
                port?: number;
                user?: string;
            }>>;
        }, "strict", z.ZodTypeAny, {
            host?: string;
            database?: string;
            password?: string;
            port?: number;
            user?: string;
            ssh?: {
                host?: string;
                password?: string;
                port?: number;
                user?: string;
            };
        }, {
            host?: string;
            database?: string;
            password?: string;
            port?: number;
            user?: string;
            ssh?: {
                host?: string;
                password?: string;
                port?: number;
                user?: string;
            };
        }>;
    }, "strict", z.ZodTypeAny, {
        options?: {
            host?: string;
            database?: string;
            password?: string;
            port?: number;
            user?: string;
            ssh?: {
                host?: string;
                password?: string;
                port?: number;
                user?: string;
            };
        };
        type?: "mysql";
    }, {
        options?: {
            host?: string;
            database?: string;
            password?: string;
            port?: number;
            user?: string;
            ssh?: {
                host?: string;
                password?: string;
                port?: number;
                user?: string;
            };
        };
        type?: "mysql";
    }>, z.ZodObject<{
        type: z.ZodLiteral<"mongodb">;
        options: z.ZodObject<{
            connection: z.ZodOptional<z.ZodString>;
            host: z.ZodOptional<z.ZodString>;
            database: z.ZodString;
            port: z.ZodOptional<z.ZodNumber>;
            user: z.ZodOptional<z.ZodString>;
            password: z.ZodOptional<z.ZodString>;
            authSource: z.ZodOptional<z.ZodString>;
            srv: z.ZodOptional<z.ZodBoolean>;
            tls: z.ZodOptional<z.ZodBoolean>;
            ssl: z.ZodOptional<z.ZodBoolean>;
            tlsCAFile: z.ZodOptional<z.ZodString>;
            tlsAllowInvalidCertificates: z.ZodOptional<z.ZodBoolean>;
        }, "strict", z.ZodTypeAny, {
            host?: string;
            database?: string;
            password?: string;
            tls?: boolean;
            connection?: string;
            port?: number;
            user?: string;
            srv?: boolean;
            authSource?: string;
            ssl?: boolean;
            tlsCAFile?: string;
            tlsAllowInvalidCertificates?: boolean;
        }, {
            host?: string;
            database?: string;
            password?: string;
            tls?: boolean;
            connection?: string;
            port?: number;
            user?: string;
            srv?: boolean;
            authSource?: string;
            ssl?: boolean;
            tlsCAFile?: string;
            tlsAllowInvalidCertificates?: boolean;
        }>;
    }, "strict", z.ZodTypeAny, {
        options?: {
            host?: string;
            database?: string;
            password?: string;
            tls?: boolean;
            connection?: string;
            port?: number;
            user?: string;
            srv?: boolean;
            authSource?: string;
            ssl?: boolean;
            tlsCAFile?: string;
            tlsAllowInvalidCertificates?: boolean;
        };
        type?: "mongodb";
    }, {
        options?: {
            host?: string;
            database?: string;
            password?: string;
            tls?: boolean;
            connection?: string;
            port?: number;
            user?: string;
            srv?: boolean;
            authSource?: string;
            ssl?: boolean;
            tlsCAFile?: string;
            tlsAllowInvalidCertificates?: boolean;
        };
        type?: "mongodb";
    }>, z.ZodObject<{
        type: z.ZodLiteral<"postgresql">;
        options: z.ZodObject<{
            host: z.ZodString;
            database: z.ZodString;
            port: z.ZodOptional<z.ZodNumber>;
            user: z.ZodOptional<z.ZodString>;
            password: z.ZodOptional<z.ZodString>;
            ssh: z.ZodOptional<z.ZodObject<{
                host: z.ZodString;
                user: z.ZodString;
                port: z.ZodOptional<z.ZodNumber>;
                password: z.ZodOptional<z.ZodString>;
            }, "strict", z.ZodTypeAny, {
                host?: string;
                password?: string;
                port?: number;
                user?: string;
            }, {
                host?: string;
                password?: string;
                port?: number;
                user?: string;
            }>>;
        } & {
            schema: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            schema?: string;
            host?: string;
            database?: string;
            password?: string;
            port?: number;
            user?: string;
            ssh?: {
                host?: string;
                password?: string;
                port?: number;
                user?: string;
            };
        }, {
            schema?: string;
            host?: string;
            database?: string;
            password?: string;
            port?: number;
            user?: string;
            ssh?: {
                host?: string;
                password?: string;
                port?: number;
                user?: string;
            };
        }>;
    }, "strict", z.ZodTypeAny, {
        options?: {
            schema?: string;
            host?: string;
            database?: string;
            password?: string;
            port?: number;
            user?: string;
            ssh?: {
                host?: string;
                password?: string;
                port?: number;
                user?: string;
            };
        };
        type?: "postgresql";
    }, {
        options?: {
            schema?: string;
            host?: string;
            database?: string;
            password?: string;
            port?: number;
            user?: string;
            ssh?: {
                host?: string;
                password?: string;
                port?: number;
                user?: string;
            };
        };
        type?: "postgresql";
    }>, z.ZodObject<{
        type: z.ZodLiteral<"supabase">;
        options: z.ZodObject<{
            accessToken: z.ZodString;
            projectRef: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            accessToken?: string;
            projectRef?: string;
        }, {
            accessToken?: string;
            projectRef?: string;
        }>;
    }, "strict", z.ZodTypeAny, {
        options?: {
            accessToken?: string;
            projectRef?: string;
        };
        type?: "supabase";
    }, {
        options?: {
            accessToken?: string;
            projectRef?: string;
        };
        type?: "supabase";
    }>, z.ZodObject<{
        type: z.ZodLiteral<"clickhouse">;
        options: z.ZodEffects<z.ZodObject<{
            host: z.ZodOptional<z.ZodString>;
            url: z.ZodOptional<z.ZodString>;
            database: z.ZodString;
            port: z.ZodOptional<z.ZodNumber>;
            user: z.ZodOptional<z.ZodString>;
            username: z.ZodOptional<z.ZodString>;
            password: z.ZodOptional<z.ZodString>;
            access_token: z.ZodOptional<z.ZodString>;
            pathname: z.ZodOptional<z.ZodString>;
            application: z.ZodOptional<z.ZodString>;
            session_id: z.ZodOptional<z.ZodString>;
            role: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>>;
            http_headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
            request_timeout: z.ZodOptional<z.ZodNumber>;
        }, "passthrough", z.ZodTypeAny, z.objectOutputType<{
            host: z.ZodOptional<z.ZodString>;
            url: z.ZodOptional<z.ZodString>;
            database: z.ZodString;
            port: z.ZodOptional<z.ZodNumber>;
            user: z.ZodOptional<z.ZodString>;
            username: z.ZodOptional<z.ZodString>;
            password: z.ZodOptional<z.ZodString>;
            access_token: z.ZodOptional<z.ZodString>;
            pathname: z.ZodOptional<z.ZodString>;
            application: z.ZodOptional<z.ZodString>;
            session_id: z.ZodOptional<z.ZodString>;
            role: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>>;
            http_headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
            request_timeout: z.ZodOptional<z.ZodNumber>;
        }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
            host: z.ZodOptional<z.ZodString>;
            url: z.ZodOptional<z.ZodString>;
            database: z.ZodString;
            port: z.ZodOptional<z.ZodNumber>;
            user: z.ZodOptional<z.ZodString>;
            username: z.ZodOptional<z.ZodString>;
            password: z.ZodOptional<z.ZodString>;
            access_token: z.ZodOptional<z.ZodString>;
            pathname: z.ZodOptional<z.ZodString>;
            application: z.ZodOptional<z.ZodString>;
            session_id: z.ZodOptional<z.ZodString>;
            role: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>>;
            http_headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
            request_timeout: z.ZodOptional<z.ZodNumber>;
        }, z.ZodTypeAny, "passthrough">>, z.objectOutputType<{
            host: z.ZodOptional<z.ZodString>;
            url: z.ZodOptional<z.ZodString>;
            database: z.ZodString;
            port: z.ZodOptional<z.ZodNumber>;
            user: z.ZodOptional<z.ZodString>;
            username: z.ZodOptional<z.ZodString>;
            password: z.ZodOptional<z.ZodString>;
            access_token: z.ZodOptional<z.ZodString>;
            pathname: z.ZodOptional<z.ZodString>;
            application: z.ZodOptional<z.ZodString>;
            session_id: z.ZodOptional<z.ZodString>;
            role: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>>;
            http_headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
            request_timeout: z.ZodOptional<z.ZodNumber>;
        }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
            host: z.ZodOptional<z.ZodString>;
            url: z.ZodOptional<z.ZodString>;
            database: z.ZodString;
            port: z.ZodOptional<z.ZodNumber>;
            user: z.ZodOptional<z.ZodString>;
            username: z.ZodOptional<z.ZodString>;
            password: z.ZodOptional<z.ZodString>;
            access_token: z.ZodOptional<z.ZodString>;
            pathname: z.ZodOptional<z.ZodString>;
            application: z.ZodOptional<z.ZodString>;
            session_id: z.ZodOptional<z.ZodString>;
            role: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>>;
            http_headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
            request_timeout: z.ZodOptional<z.ZodNumber>;
        }, z.ZodTypeAny, "passthrough">>;
    }, "strict", z.ZodTypeAny, {
        options?: {
            host?: string;
            url?: string;
            username?: string;
            database?: string;
            pathname?: string;
            request_timeout?: number;
            password?: string;
            access_token?: string;
            application?: string;
            session_id?: string;
            role?: string | string[];
            http_headers?: Record<string, string>;
            port?: number;
            user?: string;
        } & {
            [k: string]: unknown;
        };
        type?: "clickhouse";
    }, {
        options?: {
            host?: string;
            url?: string;
            username?: string;
            database?: string;
            pathname?: string;
            request_timeout?: number;
            password?: string;
            access_token?: string;
            application?: string;
            session_id?: string;
            role?: string | string[];
            http_headers?: Record<string, string>;
            port?: number;
            user?: string;
        } & {
            [k: string]: unknown;
        };
        type?: "clickhouse";
    }>, z.ZodObject<{
        type: z.ZodLiteral<"feishu-bitable">;
        options: z.ZodEffects<z.ZodObject<{
            url: z.ZodOptional<z.ZodString>;
            appToken: z.ZodOptional<z.ZodString>;
            tableId: z.ZodOptional<z.ZodString>;
            appSecret: z.ZodOptional<z.ZodString>;
            appId: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            url?: string;
            tableId?: string;
            appToken?: string;
            appSecret?: string;
            appId?: string;
        }, {
            url?: string;
            tableId?: string;
            appToken?: string;
            appSecret?: string;
            appId?: string;
        }>, {
            url?: string;
            tableId?: string;
            appToken?: string;
            appSecret?: string;
            appId?: string;
        }, {
            url?: string;
            tableId?: string;
            appToken?: string;
            appSecret?: string;
            appId?: string;
        }>;
    }, "strict", z.ZodTypeAny, {
        options?: {
            url?: string;
            tableId?: string;
            appToken?: string;
            appSecret?: string;
            appId?: string;
        };
        type?: "feishu-bitable";
    }, {
        options?: {
            url?: string;
            tableId?: string;
            appToken?: string;
            appSecret?: string;
            appId?: string;
        };
        type?: "feishu-bitable";
    }>]>, {
        type: "csv";
        options: import("../../types").CSVSourceOptions;
    } | {
        type: "json";
        options: import("../../types").JsonSourceOptions;
    } | {
        type: "text";
        options: import("../../types").TextSourceOptions;
    } | {
        type: "csv-file";
        options: import("../../types").CSVFileSourceOptions;
    } | {
        type: "json-file";
        options: import("../../types").JsonFileSourceOptions;
    } | {
        type: "parquet";
        options: import("../../types").ParquetSourceOptions;
    } | {
        type: "excel";
        options: import("../../types").ExcelSourceOptions;
    } | {
        type: "mysql";
        options: import("../../types").MySQLSourceOptions;
    } | {
        type: "postgresql";
        options: import("../../types").PostgreSQLSourceOptions;
    } | {
        type: "sqlite";
        options: import("../../types").SQLiteSourceOptions;
    } | {
        type: "mongodb";
        options: import("../../types").MongoDBSourceOptions;
    } | {
        type: "supabase";
        options: import("../../types").SupabaseSourceOptions;
    } | {
        type: "clickhouse";
        options: import("../../types").ClickHouseSourceOptions;
    } | {
        type: "feishu-bitable";
        options: import("../../types").FeishuBitableSourceOptions;
    }, {
        options?: {
            path?: string;
            options?: Record<string, unknown>;
            headers?: Record<string, string>;
        };
        type?: "csv-file";
    } | {
        options?: {
            path?: string;
            options?: Record<string, unknown>;
            headers?: Record<string, string>;
        };
        type?: "json-file";
    } | {
        options?: {
            path?: string;
            headers?: Record<string, string>;
        };
        type?: "parquet";
    } | {
        options?: {
            path?: string;
            headers?: Record<string, string>;
            sheets?: [{
                header?: boolean;
                all_varchar?: boolean;
                ignore_errors?: boolean;
                sheet?: string;
                range?: string;
                stop_at_empty?: boolean;
                empty_as_varchar?: boolean;
            }, ...{
                header?: boolean;
                all_varchar?: boolean;
                ignore_errors?: boolean;
                sheet?: string;
                range?: string;
                stop_at_empty?: boolean;
                empty_as_varchar?: boolean;
            }[]];
        };
        type?: "excel";
    } | {
        options?: {
            path?: string;
        };
        type?: "sqlite";
    } | {
        options?: {
            csv?: string;
            options?: Record<string, unknown>;
        };
        type?: "csv";
    } | {
        options?: {
            options?: Record<string, unknown>;
            data?: Record<string, unknown>[];
        };
        type?: "json";
    } | {
        options?: {
            text?: string;
        };
        type?: "text";
    } | {
        options?: {
            host?: string;
            database?: string;
            password?: string;
            port?: number;
            user?: string;
            ssh?: {
                host?: string;
                password?: string;
                port?: number;
                user?: string;
            };
        };
        type?: "mysql";
    } | {
        options?: {
            host?: string;
            database?: string;
            password?: string;
            tls?: boolean;
            connection?: string;
            port?: number;
            user?: string;
            srv?: boolean;
            authSource?: string;
            ssl?: boolean;
            tlsCAFile?: string;
            tlsAllowInvalidCertificates?: boolean;
        };
        type?: "mongodb";
    } | {
        options?: {
            schema?: string;
            host?: string;
            database?: string;
            password?: string;
            port?: number;
            user?: string;
            ssh?: {
                host?: string;
                password?: string;
                port?: number;
                user?: string;
            };
        };
        type?: "postgresql";
    } | {
        options?: {
            accessToken?: string;
            projectRef?: string;
        };
        type?: "supabase";
    } | {
        options?: {
            host?: string;
            url?: string;
            username?: string;
            database?: string;
            pathname?: string;
            request_timeout?: number;
            password?: string;
            access_token?: string;
            application?: string;
            session_id?: string;
            role?: string | string[];
            http_headers?: Record<string, string>;
            port?: number;
            user?: string;
        } & {
            [k: string]: unknown;
        };
        type?: "clickhouse";
    } | {
        options?: {
            url?: string;
            tableId?: string;
            appToken?: string;
            appSecret?: string;
            appId?: string;
        };
        type?: "feishu-bitable";
    }>;
    llm: z.ZodObject<{
        model: z.ZodString;
        apiKey: z.ZodOptional<z.ZodString>;
        baseURL: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        model?: string;
        apiKey?: string;
        baseURL?: string;
    }, {
        model?: string;
        apiKey?: string;
        baseURL?: string;
    }>;
    engine: z.ZodOptional<z.ZodEnum<["duckdb", "python", "javascript", "supabase", "clickhouse"]>>;
}, "strict", z.ZodTypeAny, {
    source?: {
        type: "csv";
        options: import("../../types").CSVSourceOptions;
    } | {
        type: "json";
        options: import("../../types").JsonSourceOptions;
    } | {
        type: "text";
        options: import("../../types").TextSourceOptions;
    } | {
        type: "csv-file";
        options: import("../../types").CSVFileSourceOptions;
    } | {
        type: "json-file";
        options: import("../../types").JsonFileSourceOptions;
    } | {
        type: "parquet";
        options: import("../../types").ParquetSourceOptions;
    } | {
        type: "excel";
        options: import("../../types").ExcelSourceOptions;
    } | {
        type: "mysql";
        options: import("../../types").MySQLSourceOptions;
    } | {
        type: "postgresql";
        options: import("../../types").PostgreSQLSourceOptions;
    } | {
        type: "sqlite";
        options: import("../../types").SQLiteSourceOptions;
    } | {
        type: "mongodb";
        options: import("../../types").MongoDBSourceOptions;
    } | {
        type: "supabase";
        options: import("../../types").SupabaseSourceOptions;
    } | {
        type: "clickhouse";
        options: import("../../types").ClickHouseSourceOptions;
    } | {
        type: "feishu-bitable";
        options: import("../../types").FeishuBitableSourceOptions;
    };
    engine?: "supabase" | "clickhouse" | "duckdb" | "python" | "javascript";
    llm?: {
        model?: string;
        apiKey?: string;
        baseURL?: string;
    };
}, {
    source?: {
        options?: {
            path?: string;
            options?: Record<string, unknown>;
            headers?: Record<string, string>;
        };
        type?: "csv-file";
    } | {
        options?: {
            path?: string;
            options?: Record<string, unknown>;
            headers?: Record<string, string>;
        };
        type?: "json-file";
    } | {
        options?: {
            path?: string;
            headers?: Record<string, string>;
        };
        type?: "parquet";
    } | {
        options?: {
            path?: string;
            headers?: Record<string, string>;
            sheets?: [{
                header?: boolean;
                all_varchar?: boolean;
                ignore_errors?: boolean;
                sheet?: string;
                range?: string;
                stop_at_empty?: boolean;
                empty_as_varchar?: boolean;
            }, ...{
                header?: boolean;
                all_varchar?: boolean;
                ignore_errors?: boolean;
                sheet?: string;
                range?: string;
                stop_at_empty?: boolean;
                empty_as_varchar?: boolean;
            }[]];
        };
        type?: "excel";
    } | {
        options?: {
            path?: string;
        };
        type?: "sqlite";
    } | {
        options?: {
            csv?: string;
            options?: Record<string, unknown>;
        };
        type?: "csv";
    } | {
        options?: {
            options?: Record<string, unknown>;
            data?: Record<string, unknown>[];
        };
        type?: "json";
    } | {
        options?: {
            text?: string;
        };
        type?: "text";
    } | {
        options?: {
            host?: string;
            database?: string;
            password?: string;
            port?: number;
            user?: string;
            ssh?: {
                host?: string;
                password?: string;
                port?: number;
                user?: string;
            };
        };
        type?: "mysql";
    } | {
        options?: {
            host?: string;
            database?: string;
            password?: string;
            tls?: boolean;
            connection?: string;
            port?: number;
            user?: string;
            srv?: boolean;
            authSource?: string;
            ssl?: boolean;
            tlsCAFile?: string;
            tlsAllowInvalidCertificates?: boolean;
        };
        type?: "mongodb";
    } | {
        options?: {
            schema?: string;
            host?: string;
            database?: string;
            password?: string;
            port?: number;
            user?: string;
            ssh?: {
                host?: string;
                password?: string;
                port?: number;
                user?: string;
            };
        };
        type?: "postgresql";
    } | {
        options?: {
            accessToken?: string;
            projectRef?: string;
        };
        type?: "supabase";
    } | {
        options?: {
            host?: string;
            url?: string;
            username?: string;
            database?: string;
            pathname?: string;
            request_timeout?: number;
            password?: string;
            access_token?: string;
            application?: string;
            session_id?: string;
            role?: string | string[];
            http_headers?: Record<string, string>;
            port?: number;
            user?: string;
        } & {
            [k: string]: unknown;
        };
        type?: "clickhouse";
    } | {
        options?: {
            url?: string;
            tableId?: string;
            appToken?: string;
            appSecret?: string;
            appId?: string;
        };
        type?: "feishu-bitable";
    };
    engine?: "supabase" | "clickhouse" | "duckdb" | "python" | "javascript";
    llm?: {
        model?: string;
        apiKey?: string;
        baseURL?: string;
    };
}>;
export declare const responseSchema: z.ZodUnion<[z.ZodObject<{
    ok: z.ZodLiteral<true>;
    result: z.ZodUnknown;
}, "strict", z.ZodTypeAny, {
    ok?: true;
    result?: unknown;
}, {
    ok?: true;
    result?: unknown;
}>, z.ZodObject<{
    ok: z.ZodLiteral<false>;
    error: z.ZodString;
}, "strict", z.ZodTypeAny, {
    error?: string;
    ok?: false;
}, {
    error?: string;
    ok?: false;
}>]>;
export declare function sessionDirectory(id: string): string;
export declare function socketPath(id: string): string;
