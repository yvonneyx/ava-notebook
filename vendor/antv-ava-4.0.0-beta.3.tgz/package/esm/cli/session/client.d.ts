import type { Request } from './protocol';
import type { DataSourceConfig, EngineConfig, LLMConfig } from '../../types';
export declare function createSession(config: DataSourceConfig, llm: LLMConfig, engine?: EngineConfig['type']): Promise<{
    datasetId: string;
}>;
export declare function request(id: string, message: Request): Promise<unknown>;
