export declare const bold: (value: string, color?: boolean) => string;
export declare const accent: (value: string, color?: boolean) => string;
export declare const muted: (value: string, color?: boolean) => string;
export declare const badge: (value: string, color?: boolean) => string;
/**
 * Formats CLI errors for terminals without affecting machine-readable output.
 */
export declare function formatError(error: unknown, color?: boolean): string;
