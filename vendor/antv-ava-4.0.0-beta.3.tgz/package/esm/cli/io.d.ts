/** Bound every input form and decode UTF-8 across stream chunk boundaries. */
export declare function readText(value: string): Promise<string>;
export declare function readJSON(value: string): Promise<unknown>;
export declare function writeHTML(path: string | undefined, html: string): Promise<{
    output: string;
}>;
