import type { LanguageModel } from 'ai';
import type { LLMConfig } from '../types';
/** Keep OpenAI-compatible endpoints on Chat Completions after the SDK upgrade. */
export declare function languageModel(llm: LLMConfig): Exclude<LanguageModel, string>;
