import { z } from 'zod';
import type { DataModel, Profile, Schema, Semantic } from '../types';
/** Validate and copy metadata without stripping semantic extensions or observations. */
export declare const dataModelMetadataSchema: z.ZodType<DataModel>;
/** Semantic definitions exclude model and column profiling metrics. */
export declare const semanticMetadataSchema: z.ZodType<Semantic>;
/** Build an independent snapshot, enriching schema and observations with named semantic definitions. */
export declare function buildDataModel(input: {
    schema: Schema;
    profile?: Profile;
    semantic?: Semantic;
}): DataModel;
/** Describe each semantic object separately, retaining source mappings, properties and observations. */
export declare function stringifyDataModel({ description, ...dataModel }: DataModel): string;
