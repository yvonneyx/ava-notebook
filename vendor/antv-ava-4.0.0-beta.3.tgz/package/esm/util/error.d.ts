export interface SerializedError {
    name?: string;
    message: string;
}
/** Convert a thrown value to serializable error details. */
export declare function serializeError(error: unknown): SerializedError;
