/**
 * Shared SQL quoting/composition helpers and DuckDB reader options.
 */
import type { CSVReadOptions, JSONReadOptions, ExcelReadOptions, FileFormat } from '../types';
/** DuckDB reader function for each file format */
export declare const READ_FN: Record<FileFormat, string>;
/** Escape a string for safe embedding in a SQL string literal */
export declare function escapeSql(value: string): string;
/** Quote a value as a SQL string literal */
export declare function sqlStringLiteral(value: string): string;
/** Combine compatible queries with UNION ALL, preserving duplicate rows. */
export declare function sqlUnionAll(queries: readonly string[]): string;
/** Quote a SQL identifier (database/schema/table name) */
export declare function sqlIdentifier(name: string): string;
/**
 * Serialize DuckDB reader options into a `, key=value, ...` SQL fragment for
 * read_csv/read_json/read_xlsx. Only undefined values are skipped; unsupported values throw.
 */
export declare function serializeOptions(options?: CSVReadOptions | JSONReadOptions | ExcelReadOptions): string;
