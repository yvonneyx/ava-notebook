/** Catalog discovery and structural validation. */
import { z } from 'zod';
import type { JsonValue, Schema } from '../types';
export declare const jsonValue: z.ZodType<JsonValue>;
export declare const schemaStructure: z.ZodObject<{
    models: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        tableReference: z.ZodObject<{
            catalog: z.ZodOptional<z.ZodString>;
            schema: z.ZodOptional<z.ZodString>;
            table: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            catalog?: string;
            schema?: string;
            table?: string;
        }, {
            catalog?: string;
            schema?: string;
            table?: string;
        }>;
        columns: z.ZodArray<z.ZodObject<{
            name: z.ZodString;
            type: z.ZodString;
            notNull: z.ZodOptional<z.ZodBoolean>;
        }, "strip", z.ZodTypeAny, {
            name?: string;
            type?: string;
            notNull?: boolean;
        }, {
            name?: string;
            type?: string;
            notNull?: boolean;
        }>, "many">;
        primaryKey: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "atleastone">]>>;
        uniqueKeys: z.ZodOptional<z.ZodArray<z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "atleastone">]>, "many">>;
    }, "strip", z.ZodTypeAny, {
        name?: string;
        columns?: {
            name?: string;
            type?: string;
            notNull?: boolean;
        }[];
        tableReference?: {
            catalog?: string;
            schema?: string;
            table?: string;
        };
        primaryKey?: string | [string, ...string[]];
        uniqueKeys?: (string | [string, ...string[]])[];
    }, {
        name?: string;
        columns?: {
            name?: string;
            type?: string;
            notNull?: boolean;
        }[];
        tableReference?: {
            catalog?: string;
            schema?: string;
            table?: string;
        };
        primaryKey?: string | [string, ...string[]];
        uniqueKeys?: (string | [string, ...string[]])[];
    }>, "many">;
    relationships: z.ZodOptional<z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        models: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        joinType: z.ZodEnum<["ONE_TO_ONE", "MANY_TO_ONE"]>;
        condition: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        name?: string;
        models?: [string, string, ...unknown[]];
        joinType?: "ONE_TO_ONE" | "MANY_TO_ONE";
        condition?: string;
    }, {
        name?: string;
        models?: [string, string, ...unknown[]];
        joinType?: "ONE_TO_ONE" | "MANY_TO_ONE";
        condition?: string;
    }>, "many">>;
    views: z.ZodOptional<z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        statement: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        name?: string;
        statement?: string;
    }, {
        name?: string;
        statement?: string;
    }>, "many">>;
}, "strip", z.ZodTypeAny, {
    models?: {
        name?: string;
        columns?: {
            name?: string;
            type?: string;
            notNull?: boolean;
        }[];
        tableReference?: {
            catalog?: string;
            schema?: string;
            table?: string;
        };
        primaryKey?: string | [string, ...string[]];
        uniqueKeys?: (string | [string, ...string[]])[];
    }[];
    relationships?: {
        name?: string;
        models?: [string, string, ...unknown[]];
        joinType?: "ONE_TO_ONE" | "MANY_TO_ONE";
        condition?: string;
    }[];
    views?: {
        name?: string;
        statement?: string;
    }[];
}, {
    models?: {
        name?: string;
        columns?: {
            name?: string;
            type?: string;
            notNull?: boolean;
        }[];
        tableReference?: {
            catalog?: string;
            schema?: string;
            table?: string;
        };
        primaryKey?: string | [string, ...string[]];
        uniqueKeys?: (string | [string, ...string[]])[];
    }[];
    relationships?: {
        name?: string;
        models?: [string, string, ...unknown[]];
        joinType?: "ONE_TO_ONE" | "MANY_TO_ONE";
        condition?: string;
    }[];
    views?: {
        name?: string;
        statement?: string;
    }[];
}>;
export declare const schemaMetadataSchema: z.ZodType<Schema>;
/** Infer column types for an in-memory model. */
export declare function extractDataSchema(data: any[]): Schema;
/** Assemble models, keys and relationships from tagged catalog rows. */
export declare function rowObjects2Schema(rows: Record<string, unknown>[]): Schema;
