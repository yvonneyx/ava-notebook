/** Value coercion helpers for typed engine query results. */
import type { QueryColumn } from '../types';
/** DuckDB serializes some numeric types as strings; text columns must remain text. */
export declare function coerceNumbers(rows: any[], schema: QueryColumn[]): any[];
