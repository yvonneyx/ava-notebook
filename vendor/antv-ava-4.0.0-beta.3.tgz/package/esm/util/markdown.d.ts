export declare function escapeMarkdown(value: string): string;
/** Use the union of row keys as headers, preserving their first-seen order. */
export declare function markdownTable(rows: object[]): string;
