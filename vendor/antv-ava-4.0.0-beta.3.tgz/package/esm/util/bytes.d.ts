/**
 * Return the UTF-8 byte length of a string.
 */
export declare function utf8ByteLength(value: string): number;
