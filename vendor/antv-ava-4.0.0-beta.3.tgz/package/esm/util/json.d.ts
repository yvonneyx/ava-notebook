/** Keep unrepairable input intact so the caller can report its parsing error. */
export declare function repairJson(text: string): string;
