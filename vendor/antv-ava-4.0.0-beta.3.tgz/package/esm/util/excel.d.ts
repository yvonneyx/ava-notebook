import { z } from 'zod';
/** Parse a bounded, inclusive A1 rectangle shared by both engines. */
export declare function excelRange(range: string): {
    firstColumn: string;
    lastColumn: string;
    firstRow: number;
    lastRow: number;
};
export declare const excelSheetSchema: z.ZodObject<{
    sheet: z.ZodString;
    range: z.ZodOptional<z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, string, string>>;
    header: z.ZodDefault<z.ZodBoolean>;
    all_varchar: z.ZodOptional<z.ZodBoolean>;
    ignore_errors: z.ZodOptional<z.ZodBoolean>;
    stop_at_empty: z.ZodOptional<z.ZodBoolean>;
    empty_as_varchar: z.ZodOptional<z.ZodBoolean>;
}, "strict", z.ZodTypeAny, {
    header?: boolean;
    all_varchar?: boolean;
    ignore_errors?: boolean;
    sheet?: string;
    range?: string;
    stop_at_empty?: boolean;
    empty_as_varchar?: boolean;
}, {
    header?: boolean;
    all_varchar?: boolean;
    ignore_errors?: boolean;
    sheet?: string;
    range?: string;
    stop_at_empty?: boolean;
    empty_as_varchar?: boolean;
}>;
export declare const excelOptionsSchema: z.ZodObject<{
    path: z.ZodString;
    headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    sheets: z.ZodOptional<z.ZodEffects<z.ZodArray<z.ZodObject<{
        sheet: z.ZodString;
        range: z.ZodOptional<z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, string, string>>;
        header: z.ZodDefault<z.ZodBoolean>;
        all_varchar: z.ZodOptional<z.ZodBoolean>;
        ignore_errors: z.ZodOptional<z.ZodBoolean>;
        stop_at_empty: z.ZodOptional<z.ZodBoolean>;
        empty_as_varchar: z.ZodOptional<z.ZodBoolean>;
    }, "strict", z.ZodTypeAny, {
        header?: boolean;
        all_varchar?: boolean;
        ignore_errors?: boolean;
        sheet?: string;
        range?: string;
        stop_at_empty?: boolean;
        empty_as_varchar?: boolean;
    }, {
        header?: boolean;
        all_varchar?: boolean;
        ignore_errors?: boolean;
        sheet?: string;
        range?: string;
        stop_at_empty?: boolean;
        empty_as_varchar?: boolean;
    }>, "atleastone">, [{
        header?: boolean;
        all_varchar?: boolean;
        ignore_errors?: boolean;
        sheet?: string;
        range?: string;
        stop_at_empty?: boolean;
        empty_as_varchar?: boolean;
    }, ...{
        header?: boolean;
        all_varchar?: boolean;
        ignore_errors?: boolean;
        sheet?: string;
        range?: string;
        stop_at_empty?: boolean;
        empty_as_varchar?: boolean;
    }[]], [{
        header?: boolean;
        all_varchar?: boolean;
        ignore_errors?: boolean;
        sheet?: string;
        range?: string;
        stop_at_empty?: boolean;
        empty_as_varchar?: boolean;
    }, ...{
        header?: boolean;
        all_varchar?: boolean;
        ignore_errors?: boolean;
        sheet?: string;
        range?: string;
        stop_at_empty?: boolean;
        empty_as_varchar?: boolean;
    }[]]>>;
}, "strict", z.ZodTypeAny, {
    path?: string;
    headers?: Record<string, string>;
    sheets?: [{
        header?: boolean;
        all_varchar?: boolean;
        ignore_errors?: boolean;
        sheet?: string;
        range?: string;
        stop_at_empty?: boolean;
        empty_as_varchar?: boolean;
    }, ...{
        header?: boolean;
        all_varchar?: boolean;
        ignore_errors?: boolean;
        sheet?: string;
        range?: string;
        stop_at_empty?: boolean;
        empty_as_varchar?: boolean;
    }[]];
}, {
    path?: string;
    headers?: Record<string, string>;
    sheets?: [{
        header?: boolean;
        all_varchar?: boolean;
        ignore_errors?: boolean;
        sheet?: string;
        range?: string;
        stop_at_empty?: boolean;
        empty_as_varchar?: boolean;
    }, ...{
        header?: boolean;
        all_varchar?: boolean;
        ignore_errors?: boolean;
        sheet?: string;
        range?: string;
        stop_at_empty?: boolean;
        empty_as_varchar?: boolean;
    }[]];
}>;
