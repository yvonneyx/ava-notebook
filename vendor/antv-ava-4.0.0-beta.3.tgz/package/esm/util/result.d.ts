import type { ExecutionOptions, ExecutionResult, QueryColumn } from '../types';
/**
 * Get the bounded maximum row count.
 */
export declare function maxRows(options?: ExecutionOptions): number;
/**
 * Get the bounded maximum serialized result size.
 */
export declare function maxResultBytes(options?: ExecutionOptions): number;
/**
 * Create a SQL query with a row limit.
 */
export declare function limitedQuery(sql: string, limit: number): string;
/**
 * Create a bounded execution result, preserving upstream truncation unless a local limit truncates further.
 */
export declare function executionResult<T>(rows: T[], schema: QueryColumn[], options?: ExecutionOptions, upstreamTruncatedBy?: ExecutionResult<T>['truncatedBy']): ExecutionResult<T>;
/**
 * Infer column metadata from result rows.
 */
export declare function inferQuerySchema(rows: unknown[]): QueryColumn[];
