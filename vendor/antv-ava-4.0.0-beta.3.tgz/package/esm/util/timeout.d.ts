/** Bound waiting for an operation; cancellation belongs to the caller. */
export declare function runWithTimeout<T>(operation: Promise<T>, timeoutMs: number, options: {
    onTimeout: () => Error;
    unref?: boolean;
}): Promise<T>;
