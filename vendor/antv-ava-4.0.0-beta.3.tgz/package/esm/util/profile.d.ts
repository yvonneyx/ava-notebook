import { z } from 'zod';
import type { Metric, MetricConfig, ProfileOptions, ParsedProfileOptions, LogicalType, Profile, Schema } from '../types';
export type MetricField = Schema['models'][number]['columns'][number] & {
    logicalType: LogicalType;
};
export declare const profileMetadataSchema: z.ZodType<Profile>;
export declare function parseMetricConfig(config: MetricConfig): Exclude<MetricConfig, string>;
/** Resolve a metric definition and validate its supplied options. */
export declare function resolveMetric<T extends Metric>(config: Exclude<MetricConfig, string>, definitions: T[]): T;
/** Normalize metric selections, using defaults when no selection is supplied. */
export declare function parseProfileOptions(options: ProfileOptions, defaultOptions: ProfileOptions): ParsedProfileOptions;
export declare const table: Metric['enable'];
export declare const column: Metric['enable'];
export declare const logicalTypes: (...types: LogicalType[]) => Metric["enable"];
export declare const TOP_VALUES_OPTIONS: NonNullable<Metric['options']>;
export declare const DEFAULT_METRICS: string[];
