/**
 * Suggest module for generating recommended analysis queries
 */
import type { LLMConfig, DataModel, SuggestResult } from '../types';
/**
 * Generate suggested analysis queries based on dataset
 */
export declare function generateSuggestions(llmConfig: LLMConfig, dataModel: DataModel, count?: number): Promise<SuggestResult[]>;
